# 🅿️ ParkSmart — الدليل الكامل للنشر على GitHub

## 📁 محتوى هذا المجلد

```
parksmart-web/
├── index.html                        ← التطبيق الكامل (كل الشاشات)
├── README.md                         ← هذا الملف
└── .github/
    └── workflows/
        └── deploy.yml                ← النشر التلقائي
```

---

## 🚀 خطوات الرفع على GitHub (بالترتيب)

### الخطوة 1 — إنشاء حساب GitHub
- اذهب إلى: **https://github.com**
- اضغط **Sign up** وأنشئ حساباً مجانياً

---

### الخطوة 2 — إنشاء Repository جديد
1. اضغط على **"+"** في أعلى اليمين
2. اختر **"New repository"**
3. في **Repository name** اكتب: `parksmart`
4. اختر **Public** ✅
5. **لا تضف** أي ملفات (لا README، لا .gitignore)
6. اضغط **"Create repository"**

---

### الخطوة 3 — رفع الملفات

#### الطريقة السهلة (بدون Git):
1. في صفحة الـ Repository الجديدة، اضغط **"uploading an existing file"**
2. اسحب وأفلت **كل الملفات** من المجلد:
   - `index.html`
   - مجلد `.github` كاملاً (مع `workflows/deploy.yml`)
3. في أسفل الصفحة، اضغط **"Commit changes"**

> ⚠️ **مهم**: تأكد من رفع مجلد `.github/workflows/deploy.yml`
> بعض الأنظمة تخفي المجلدات التي تبدأ بنقطة.
> إذا لم تستطع رفعه، راجع الخطوة 4 البديلة أدناه.

---

### الخطوة 4 — تفعيل GitHub Pages
1. في صفحة الـ Repository، اضغط **Settings** (الإعدادات)
2. في القائمة الجانبية اضغط **Pages**
3. تحت **Source** اختر: **GitHub Actions**
4. احفظ

---

### الخطوة 5 — انتظر الموقع يشتغل!
- بعد دقيقة واحدة، اذهب إلى:

```
https://اسم-المستخدم.github.io/parksmart
```

مثال: إذا اسمك `ahmed123` فالرابط هو:
```
https://ahmed123.github.io/parksmart
```

---

## 📱 الموقع يعمل على:
- ✅ الحاسوب (Chrome, Firefox, Safari, Edge)
- ✅ الهاتف الذكي (Android + iPhone)
- ✅ الأجهزة اللوحية
- ✅ يمكن إضافته للشاشة الرئيسية كتطبيق!

---

## ❓ إذا لم يشتغل deploy.yml

### الطريقة البديلة (الأسهل):
1. في **Settings → Pages**
2. تحت **Source** اختر **Deploy from a branch**
3. اختر **Branch: main** و **Folder: / (root)**
4. اضغط **Save**
5. انتظر دقيقة واحدة

---

## 🌍 اللغات المدعومة
| اللغة | الاختيار |
|-------|---------|
| العربية 🇩🇿 | RTL كامل |
| Français 🇫🇷 | LTR |
| English 🇬🇧 | LTR |

---

## 📞 مساعدة
إذا واجهت أي مشكلة، راسلنا على: contact@parksmart.dz
