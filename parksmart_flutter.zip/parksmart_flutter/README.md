# 🅿️ ParkSmart — تطبيق المواقف الذكي

> نظام إدارة المواقف الذكي | Système de stationnement intelligent | Smart Parking System  
> الجزائر — Algeria 🇩🇿

---

## 📱 نظرة عامة

تطبيق Flutter كامل لإدارة مواقف السيارات الذكية بثلاث لغات:
- 🇩🇿 **العربية** (RTL)
- 🇫🇷 **Français**
- 🇬🇧 **English**

---

## 🏗️ هيكل المشروع

```
parksmart/
├── lib/
│   ├── main.dart                    ← نقطة الدخول + التوجيه
│   ├── theme/
│   │   └── app_theme.dart           ← الألوان + الخطوط + الثيم
│   ├── models/
│   │   └── models.dart              ← نماذج البيانات
│   ├── services/
│   │   └── app_state.dart           ← إدارة الحالة (Riverpod)
│   ├── widgets/
│   │   └── widgets.dart             ← مكونات مشتركة
│   ├── l10n/
│   │   ├── app_ar.arb               ← ترجمة عربية
│   │   ├── app_fr.arb               ← ترجمة فرنسية
│   │   └── app_en.arb               ← ترجمة إنجليزية
│   └── screens/
│       ├── auth/
│       │   └── auth_screens.dart    ← Splash + Login + Register + OTP
│       ├── home/
│       │   └── home_screen.dart     ← الصفحة الرئيسية
│       ├── scan/
│       │   └── scan_screen.dart     ← مسح QR Code
│       ├── session/
│       │   └── session_screen.dart  ← الجلسة النشطة + المؤقت
│       ├── wallet/
│       │   └── wallet_screen.dart   ← المحفظة + الشحن + الاشتراكات
│       ├── other_screens.dart       ← History + Vehicles + Profile
│       └── main_shell.dart          ← Bottom Navigation Shell
├── android/
│   └── app/src/main/AndroidManifest.xml
├── ios/
│   └── Runner/Info.plist
├── pubspec.yaml
└── l10n.yaml
```

---

## 🚀 تشغيل المشروع

### المتطلبات
```bash
Flutter SDK >= 3.0.0
Dart >= 3.0.0
Android Studio / VS Code
Android SDK (API 21+) أو iOS 13+
```

### الخطوات

```bash
# 1. استنساخ المشروع
git clone https://github.com/your-org/parksmart.git
cd parksmart

# 2. تثبيت الحزم
flutter pub get

# 3. توليد ملفات الترجمة
flutter gen-l10n

# 4. توليد كود Riverpod
flutter pub run build_runner build --delete-conflicting-outputs

# 5. تشغيل التطبيق
flutter run

# 6. بناء APK للأندرويد
flutter build apk --release

# 7. بناء iOS
flutter build ios --release
```

---

## 📋 الشاشات

| الشاشة | الوصف |
|--------|-------|
| **Splash** | شاشة البداية مع الشعار |
| **Login** | تسجيل دخول بالهاتف وكلمة المرور |
| **Register** | إنشاء حساب + التحقق OTP |
| **Home** | الرصيد + الجلسة النشطة + إجراءات سريعة |
| **Scan QR** | مسح رمز العداد بالكاميرا |
| **Session** | مؤقت حي + تكلفة تلقائية + إيقاف |
| **Wallet** | شحن الرصيد + خطط الاشتراك |
| **History** | سجل المواقف + المخالفات |
| **Vehicles** | إدارة السيارات المسجلة |
| **Profile** | الملف الشخصي + اللغة + الإعدادات |

---

## 💰 منطق حساب التكلفة

```dart
// كل 5 دقائق = $0.25
double cost = (elapsedMinutes / 5).ceil() * pricePerFiveMin;

// مثال: 23 دقيقة
// ceil(23/5) = 5 فترات
// 5 × $0.25 = $1.25
```

---

## 🔒 أمان QR Code

```json
{
  "meter_id": 1283,
  "zone_id": "z_002",
  "city": "Algiers",
  "signature": "HMAC_SHA256_TOKEN",
  "timestamp": 1741600000
}
```

التحقق من التوقيع يمنع استخدام رموز QR مزيفة.

---

## 🔧 API Endpoints (Backend)

```
POST   /api/auth/login
POST   /api/auth/register
POST   /api/auth/verify-otp

GET    /api/user/profile
PATCH  /api/user/balance

POST   /api/sessions/start
POST   /api/sessions/stop
GET    /api/sessions/active
GET    /api/sessions/history

POST   /api/payments/recharge
GET    /api/payments/history

POST   /api/qr/verify

GET    /api/zones
GET    /api/meters/:id
```

---

## 📦 الحزم المستخدمة

| الحزمة | الغرض |
|--------|--------|
| `flutter_riverpod` | إدارة الحالة |
| `flutter_animate` | الأنيميشن |
| `mobile_scanner` | مسح QR |
| `google_fonts` | خط Cairo |
| `flutter_localizations` | الترجمة المتعددة |
| `go_router` | التنقل |
| `dio` | HTTP requests |
| `flutter_local_notifications` | إشعارات محلية |
| `flutter_secure_storage` | تخزين آمن للـ token |

---

## 🌍 إضافة لغة جديدة

```bash
# 1. إنشاء ملف ARB جديد
lib/l10n/app_es.arb  # إسبانية مثلاً

# 2. إضافة Locale للمشروع في main.dart
Locale('es'),

# 3. توليد الكود
flutter gen-l10n
```

---

## 👨‍💻 المطور

**ParkSmart Team — الجزائر**  
contact@parksmart.dz

---

*مشروع تخرج / Projet de fin d'études / Graduation Project*  
*جامعة الجزائر — 2026*
