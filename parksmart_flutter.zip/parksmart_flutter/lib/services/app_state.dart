import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';

// ─────────────────────────────────────────
//  Language Provider
// ─────────────────────────────────────────
final languageProvider = StateNotifierProvider<LanguageNotifier, Locale>(
  (ref) => LanguageNotifier(),
);

class LanguageNotifier extends StateNotifier<Locale> {
  LanguageNotifier() : super(const Locale('ar'));

  void setLanguage(String langCode) {
    state = Locale(langCode);
  }

  bool get isRtl => state.languageCode == 'ar';
}

// ─────────────────────────────────────────
//  Auth Provider
// ─────────────────────────────────────────
enum AuthStatus { unauthenticated, loading, authenticated }

class AuthState {
  final AuthStatus status;
  final UserModel? user;
  final String? error;

  const AuthState({
    this.status = AuthStatus.unauthenticated,
    this.user,
    this.error,
  });

  AuthState copyWith({AuthStatus? status, UserModel? user, String? error}) {
    return AuthState(
      status: status ?? this.status,
      user: user ?? this.user,
      error: error,
    );
  }
}

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>(
  (ref) => AuthNotifier(),
);

class AuthNotifier extends StateNotifier<AuthState> {
  AuthNotifier() : super(const AuthState());

  Future<void> login(String phone, String password) async {
    state = state.copyWith(status: AuthStatus.loading);
    await Future.delayed(const Duration(seconds: 1));
    // Mock login — replace with real API call
    state = state.copyWith(
      status: AuthStatus.authenticated,
      user: UserModel.mock(),
    );
  }

  Future<void> register({
    required String name,
    required String phone,
    required String email,
    required String password,
  }) async {
    state = state.copyWith(status: AuthStatus.loading);
    await Future.delayed(const Duration(seconds: 1));
    state = state.copyWith(
      status: AuthStatus.authenticated,
      user: UserModel(
        id: 'usr_new',
        name: name, phone: phone, email: email,
        accountBalance: 0.0,
        createdAt: DateTime.now(),
      ),
    );
  }

  void logout() {
    state = const AuthState(status: AuthStatus.unauthenticated);
  }

  Future<void> rechargeBalance(double amount) async {
    if (state.user == null) return;
    await Future.delayed(const Duration(milliseconds: 500));
    state = state.copyWith(
      user: state.user!.copyWith(
        accountBalance: state.user!.accountBalance + amount,
      ),
    );
  }

  void deductBalance(double amount) {
    if (state.user == null) return;
    state = state.copyWith(
      user: state.user!.copyWith(
        accountBalance: (state.user!.accountBalance - amount).clamp(0, double.infinity),
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Parking Session Provider
// ─────────────────────────────────────────
class SessionState {
  final ParkingSessionModel? activeSession;
  final List<ParkingSessionModel> history;
  final bool isLoading;

  const SessionState({
    this.activeSession,
    this.history = const [],
    this.isLoading = false,
  });

  bool get hasActiveSession => activeSession != null &&
    activeSession!.status == SessionStatus.active;

  SessionState copyWith({
    ParkingSessionModel? activeSession,
    List<ParkingSessionModel>? history,
    bool? isLoading,
    bool clearActive = false,
  }) {
    return SessionState(
      activeSession: clearActive ? null : (activeSession ?? this.activeSession),
      history: history ?? this.history,
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

final sessionProvider = StateNotifierProvider<SessionNotifier, SessionState>(
  (ref) => SessionNotifier(ref),
);

class SessionNotifier extends StateNotifier<SessionState> {
  final Ref _ref;

  SessionNotifier(this._ref) : super(SessionState(
    history: ParkingSessionModel.mockHistory,
  ));

  Future<bool> startSession({
    required String userId,
    required String vehicleId,
    required String vehiclePlate,
    required MeterModel meter,
    required ZoneModel zone,
  }) async {
    state = state.copyWith(isLoading: true);
    await Future.delayed(const Duration(milliseconds: 800));

    final session = ParkingSessionModel(
      id: 'sess_${DateTime.now().millisecondsSinceEpoch}',
      userId: userId,
      vehicleId: vehicleId,
      meterId: meter.id,
      zoneId: zone.id,
      zoneName: zone.name,
      vehiclePlate: vehiclePlate,
      startTime: DateTime.now(),
      pricePerFiveMin: zone.pricePerFiveMin,
      status: SessionStatus.active,
    );

    state = state.copyWith(activeSession: session, isLoading: false);
    return true;
  }

  Future<ParkingSessionModel?> stopSession() async {
    if (state.activeSession == null) return null;
    state = state.copyWith(isLoading: true);
    await Future.delayed(const Duration(milliseconds: 500));

    final ended = state.activeSession!.copyWith(
      status: SessionStatus.completed,
      endTime: DateTime.now(),
      cost: state.activeSession!.currentCost,
    );

    // Deduct from wallet
    _ref.read(authProvider.notifier).deductBalance(ended.cost);

    state = state.copyWith(
      history: [ended, ...state.history],
      isLoading: false,
      clearActive: true,
    );
    return ended;
  }

  void loadHistory() {
    state = state.copyWith(history: ParkingSessionModel.mockHistory);
  }
}

// ─────────────────────────────────────────
//  Bottom Nav Index Provider
// ─────────────────────────────────────────
final bottomNavIndexProvider = StateProvider<int>((ref) => 0);

// ─────────────────────────────────────────
//  Payment History Provider
// ─────────────────────────────────────────
final paymentsProvider = StateNotifierProvider<PaymentsNotifier, List<PaymentModel>>(
  (ref) => PaymentsNotifier(),
);

class PaymentsNotifier extends StateNotifier<List<PaymentModel>> {
  PaymentsNotifier() : super(PaymentModel.mockHistory);

  void addPayment(PaymentModel payment) {
    state = [payment, ...state];
  }
}

// ─────────────────────────────────────────
//  Vehicles Provider
// ─────────────────────────────────────────
final vehiclesProvider = StateNotifierProvider<VehiclesNotifier, List<VehicleModel>>(
  (ref) {
    final user = ref.watch(authProvider).user;
    return VehiclesNotifier(user?.vehicles ?? []);
  },
);

class VehiclesNotifier extends StateNotifier<List<VehicleModel>> {
  VehiclesNotifier(List<VehicleModel> initial) : super(initial);

  void addVehicle(VehicleModel vehicle) {
    state = [...state, vehicle];
  }

  void setDefault(String vehicleId) {
    state = state.map((v) => VehicleModel(
      id: v.id, userId: v.userId, plateNumber: v.plateNumber,
      vehicleType: v.vehicleType, model: v.model,
      isDefault: v.id == vehicleId,
      createdAt: v.createdAt,
    )).toList();
  }

  void removeVehicle(String vehicleId) {
    state = state.where((v) => v.id != vehicleId).toList();
  }

  VehicleModel? get defaultVehicle => state.firstWhere(
    (v) => v.isDefault,
    orElse: () => state.first,
  );
}
