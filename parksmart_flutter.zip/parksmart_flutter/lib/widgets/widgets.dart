import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_theme.dart';

// ─────────────────────────────────────────
//  AppCard
// ─────────────────────────────────────────
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final bool accent;
  final VoidCallback? onTap;
  final Color? borderColor;
  final Gradient? gradient;
  final double? borderRadius;

  const AppCard({
    super.key,
    required this.child,
    this.padding,
    this.accent = false,
    this.onTap,
    this.borderColor,
    this.gradient,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: padding ?? const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: gradient == null ? AppColors.card : null,
          gradient: gradient,
          borderRadius: BorderRadius.circular(borderRadius ?? 20),
          border: Border.all(
            color: borderColor ?? (accent ? AppColors.borderAccent : AppColors.border),
            width: 1,
          ),
        ),
        child: child,
      ),
    );
  }
}

// ─────────────────────────────────────────
//  AppButton
// ─────────────────────────────────────────
enum AppButtonVariant { primary, secondary, danger, ghost, gold }

class AppButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final AppButtonVariant variant;
  final bool fullWidth;
  final bool loading;
  final IconData? icon;
  final double height;

  const AppButton({
    super.key,
    required this.label,
    this.onPressed,
    this.variant = AppButtonVariant.primary,
    this.fullWidth = true,
    this.loading = false,
    this.icon,
    this.height = 52,
  });

  @override
  Widget build(BuildContext context) {
    final styles = {
      AppButtonVariant.primary: (
        bg: AppColors.accent,
        fg: Colors.black,
        border: Colors.transparent,
        shadow: const Color(0x40009966),
      ),
      AppButtonVariant.secondary: (
        bg: AppColors.blue,
        fg: Colors.white,
        border: Colors.transparent,
        shadow: const Color(0x401A8CFF),
      ),
      AppButtonVariant.danger: (
        bg: AppColors.warnDim,
        fg: AppColors.warn,
        border: const Color(0x4DFF5E3A),
        shadow: Colors.transparent,
      ),
      AppButtonVariant.ghost: (
        bg: const Color(0x0DFFFFFF),
        fg: AppColors.textPrimary,
        border: AppColors.border,
        shadow: Colors.transparent,
      ),
      AppButtonVariant.gold: (
        bg: AppColors.gold,
        fg: Colors.black,
        border: Colors.transparent,
        shadow: const Color(0x40F5C842),
      ),
    };

    final s = styles[variant]!;

    return SizedBox(
      width: fullWidth ? double.infinity : null,
      height: height,
      child: ElevatedButton(
        onPressed: loading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: s.bg,
          foregroundColor: s.fg,
          disabledBackgroundColor: s.bg.withOpacity(0.5),
          elevation: 0,
          shadowColor: s.shadow,
          side: BorderSide(color: s.border),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          padding: EdgeInsets.symmetric(
            horizontal: fullWidth ? 20 : 24,
            vertical: 0,
          ),
        ),
        child: loading
          ? SizedBox(
              width: 22, height: 22,
              child: CircularProgressIndicator(
                strokeWidth: 2.5,
                color: s.fg,
              ),
            )
          : Row(
              mainAxisSize: fullWidth ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[
                  Icon(icon, size: 18),
                  const SizedBox(width: 8),
                ],
                Text(
                  label,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: s.fg,
                  ),
                ),
              ],
            ),
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Section Header
// ─────────────────────────────────────────
class SectionHeader extends StatelessWidget {
  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;

  const SectionHeader({
    super.key,
    required this.title,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: const TextStyle(
            fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          )),
          if (actionLabel != null)
            GestureDetector(
              onTap: onAction,
              child: Text(actionLabel!, style: const TextStyle(
                fontFamily: 'Cairo', fontSize: 12, fontWeight: FontWeight.w600,
                color: AppColors.accent,
              )),
            ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Status Badge
// ─────────────────────────────────────────
enum BadgeColor { accent, blue, warn, gold, muted, purple }

class StatusBadge extends StatelessWidget {
  final String label;
  final BadgeColor color;
  final bool withDot;

  const StatusBadge({
    super.key,
    required this.label,
    this.color = BadgeColor.accent,
    this.withDot = false,
  });

  @override
  Widget build(BuildContext context) {
    final colors = {
      BadgeColor.accent: (bg: AppColors.accentDim, text: AppColors.accent),
      BadgeColor.blue: (bg: AppColors.blueDim, text: AppColors.blue),
      BadgeColor.warn: (bg: AppColors.warnDim, text: AppColors.warn),
      BadgeColor.gold: (bg: AppColors.goldDim, text: AppColors.gold),
      BadgeColor.muted: (bg: const Color(0x0DFFFFFF), text: AppColors.textMuted),
      BadgeColor.purple: (bg: AppColors.purpleDim, text: AppColors.purple),
    };
    final c = colors[color]!;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: c.bg,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (withDot) ...[
            PulseDot(color: c.text),
            const SizedBox(width: 5),
          ],
          Text(label, style: TextStyle(
            fontFamily: 'Cairo', fontSize: 11,
            fontWeight: FontWeight.w700, color: c.text,
          )),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Pulse Dot
// ─────────────────────────────────────────
class PulseDot extends StatelessWidget {
  final Color color;
  final double size;

  const PulseDot({
    super.key,
    this.color = AppColors.accent,
    this.size = 8,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    )
    .animate(onPlay: (c) => c.repeat())
    .scaleXY(begin: 1, end: 1.4, duration: 750.ms)
    .then()
    .scaleXY(begin: 1.4, end: 1, duration: 750.ms);
  }
}

// ─────────────────────────────────────────
//  Mono Text (for timers, amounts, codes)
// ─────────────────────────────────────────
class MonoText extends StatelessWidget {
  final String text;
  final double size;
  final Color? color;
  final FontWeight weight;
  final double letterSpacing;

  const MonoText(
    this.text, {
    super.key,
    this.size = 14,
    this.color,
    this.weight = FontWeight.w700,
    this.letterSpacing = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Text(text, style: TextStyle(
      fontFamily: 'JetBrains Mono',
      fontSize: size,
      fontWeight: weight,
      color: color ?? AppColors.textPrimary,
      letterSpacing: letterSpacing,
    ));
  }
}

// ─────────────────────────────────────────
//  Balance Card
// ─────────────────────────────────────────
class BalanceCard extends StatelessWidget {
  final double balance;
  final VoidCallback onAddPressed;

  const BalanceCard({
    super.key,
    required this.balance,
    required this.onAddPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0x1A00E5A0), Color(0x101A8CFF)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.borderAccent),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'الرصيد المتاح',
                  style: TextStyle(
                    fontFamily: 'Cairo', fontSize: 12,
                    color: AppColors.textMuted,
                  ),
                ),
                const SizedBox(height: 6),
                MonoText(
                  '\$${balance.toStringAsFixed(2)}',
                  size: 30, color: AppColors.accent,
                  letterSpacing: 2,
                ),
                const SizedBox(height: 4),
                Text(
                  '~ ${(balance / 0.25 * 5).toStringAsFixed(0)} دقيقة وقوف',
                  style: const TextStyle(
                    fontFamily: 'Cairo', fontSize: 11,
                    color: AppColors.textMuted,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onAddPressed,
            child: Container(
              width: 50, height: 50,
              decoration: BoxDecoration(
                color: AppColors.accent,
                borderRadius: BorderRadius.circular(16),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x6600E5A0),
                    blurRadius: 20, offset: Offset(0, 6),
                  ),
                ],
              ),
              child: const Icon(Icons.add_rounded, color: Colors.black, size: 26),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Stat Card
// ─────────────────────────────────────────
class StatCard extends StatelessWidget {
  final String value;
  final String label;
  final Color color;

  const StatCard({
    super.key,
    required this.value,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      child: Column(
        children: [
          MonoText(value, size: 20, color: color),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(
            fontFamily: 'Cairo', fontSize: 10, color: AppColors.textMuted,
          ), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Info Row (label + value)
// ─────────────────────────────────────────
class InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  final bool mono;

  const InfoRow({
    super.key,
    required this.label,
    required this.value,
    this.valueColor,
    this.mono = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(
          fontFamily: 'Cairo', fontSize: 11, color: AppColors.textMuted,
        )),
        const SizedBox(height: 4),
        mono
          ? MonoText(value, size: 14, color: valueColor)
          : Text(value, style: TextStyle(
              fontFamily: 'Cairo', fontSize: 15,
              fontWeight: FontWeight.w700,
              color: valueColor ?? AppColors.textPrimary,
            )),
      ],
    );
  }
}

// ─────────────────────────────────────────
//  Quick Action Button
// ─────────────────────────────────────────
class QuickActionTile extends StatelessWidget {
  final String icon;
  final String label;
  final String subtitle;
  final Color iconBg;
  final VoidCallback onTap;

  const QuickActionTile({
    super.key,
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.iconBg,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.all(16),
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(child: Text(icon, style: const TextStyle(fontSize: 22))),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(
                  fontFamily: 'Cairo', fontSize: 13,
                  fontWeight: FontWeight.w700, color: AppColors.textPrimary,
                )),
                const SizedBox(height: 3),
                Text(subtitle, style: const TextStyle(
                  fontFamily: 'Cairo', fontSize: 11, color: AppColors.textMuted,
                )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
