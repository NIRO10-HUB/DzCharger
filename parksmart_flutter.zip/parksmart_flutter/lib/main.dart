import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import 'theme/app_theme.dart';
import 'services/app_state.dart';
import 'screens/auth/auth_screens.dart';
import 'screens/main_shell.dart';
import 'screens/other_screens.dart';

// ─────────────────────────────────────────
//  Entry Point
// ─────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Force portrait mode
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Transparent status bar
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  runApp(
    const ProviderScope(
      child: ParkSmartApp(),
    ),
  );
}

// ─────────────────────────────────────────
//  Root App
// ─────────────────────────────────────────
class ParkSmartApp extends ConsumerWidget {
  const ParkSmartApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(languageProvider);
    final authState = ref.watch(authProvider);

    return MaterialApp(
      title: 'ParkSmart',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      locale: locale,

      // ── Localization ──
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('ar'), // Arabic (RTL)
        Locale('fr'), // French
        Locale('en'), // English
      ],

      // ── RTL Support ──
      builder: (context, child) {
        final l = AppLocalizations.of(context);
        final isRtl = locale.languageCode == 'ar';

        return Directionality(
          textDirection: isRtl ? TextDirection.rtl : TextDirection.ltr,
          child: child ?? const SizedBox(),
        );
      },

      // ── Initial Route ──
      initialRoute: '/splash',

      // ── Named Routes ──
      routes: {
        '/splash': (_) => const SplashScreen(),
        '/login': (_) => const LoginScreen(),
        '/register': (_) => const RegisterScreen(),
        '/home': (_) => const MainShell(),
        '/vehicles': (_) => const VehiclesScreen(),
        '/profile': (_) => const ProfileScreen(),
      },

      // ── Redirect if not authenticated ──
      onGenerateRoute: (settings) {
        // Protected routes
        final protectedRoutes = ['/home', '/vehicles', '/profile'];
        if (protectedRoutes.contains(settings.name) &&
            authState.status != AuthStatus.authenticated) {
          return MaterialPageRoute(builder: (_) => const LoginScreen());
        }
        return null;
      },
    );
  }
}
