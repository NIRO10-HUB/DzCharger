import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

// ─────────────────────────────────────────
//  ParkSmart Color Palette
// ─────────────────────────────────────────
class AppColors {
  // Background layers
  static const bg = Color(0xFF07090F);
  static const surface = Color(0xFF0D1017);
  static const card = Color(0xFF121722);
  static const card2 = Color(0xFF161D2A);

  // Accent colors
  static const accent = Color(0xFF00E5A0);
  static const accentDim = Color(0x1F00E5A0);
  static const blue = Color(0xFF1A8CFF);
  static const blueDim = Color(0x1F1A8CFF);
  static const warn = Color(0xFFFF5E3A);
  static const warnDim = Color(0x1FFF5E3A);
  static const gold = Color(0xFFF5C842);
  static const goldDim = Color(0x1FF5C842);
  static const purple = Color(0xFFA080FF);
  static const purpleDim = Color(0x1FA080FF);

  // Text
  static const textPrimary = Color(0xFFDDE4F0);
  static const textMuted = Color(0xFF4A5470);
  static const textSubtle = Color(0xFF2E3550);

  // Borders
  static const border = Color(0x0FFFFFFF);
  static const borderAccent = Color(0x40009966);

  // Gradients
  static const gradientHeader = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF0D1A2E), Color(0xFF0A1218)],
  );

  static const gradientAccent = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF00E5A0), Color(0xFF1A8CFF)],
  );

  static const gradientCard = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0x1A00E5A0), Color(0x0F1A8CFF)],
  );
}

// ─────────────────────────────────────────
//  ParkSmart Text Styles
// ─────────────────────────────────────────
class AppTextStyles {
  static TextStyle get displayLarge => GoogleFonts.cairo(
    fontSize: 32, fontWeight: FontWeight.w900,
    color: AppColors.textPrimary, height: 1.2,
  );

  static TextStyle get displayMedium => GoogleFonts.cairo(
    fontSize: 24, fontWeight: FontWeight.w800,
    color: AppColors.textPrimary, height: 1.3,
  );

  static TextStyle get headlineLarge => GoogleFonts.cairo(
    fontSize: 20, fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
  );

  static TextStyle get headlineMedium => GoogleFonts.cairo(
    fontSize: 18, fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
  );

  static TextStyle get titleLarge => GoogleFonts.cairo(
    fontSize: 16, fontWeight: FontWeight.w700,
    color: AppColors.textPrimary,
  );

  static TextStyle get titleMedium => GoogleFonts.cairo(
    fontSize: 14, fontWeight: FontWeight.w600,
    color: AppColors.textPrimary,
  );

  static TextStyle get bodyLarge => GoogleFonts.cairo(
    fontSize: 15, fontWeight: FontWeight.w400,
    color: AppColors.textPrimary,
  );

  static TextStyle get bodyMedium => GoogleFonts.cairo(
    fontSize: 13, fontWeight: FontWeight.w400,
    color: AppColors.textPrimary,
  );

  static TextStyle get bodySmall => GoogleFonts.cairo(
    fontSize: 11, fontWeight: FontWeight.w400,
    color: AppColors.textMuted,
  );

  static TextStyle get labelLarge => GoogleFonts.cairo(
    fontSize: 14, fontWeight: FontWeight.w700,
    color: AppColors.textPrimary, letterSpacing: 0.3,
  );

  static TextStyle get monoLarge => const TextStyle(
    fontFamily: 'JetBrains Mono', fontSize: 32,
    fontWeight: FontWeight.w700, color: AppColors.accent,
    letterSpacing: 4,
  );

  static TextStyle get monoMedium => const TextStyle(
    fontFamily: 'JetBrains Mono', fontSize: 16,
    fontWeight: FontWeight.w700, color: AppColors.textPrimary,
    letterSpacing: 1,
  );

  static TextStyle get monoSmall => const TextStyle(
    fontFamily: 'JetBrains Mono', fontSize: 12,
    fontWeight: FontWeight.w400, color: AppColors.textMuted,
    letterSpacing: 1,
  );
}

// ─────────────────────────────────────────
//  ParkSmart Theme
// ─────────────────────────────────────────
class AppTheme {
  static ThemeData get dark {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.bg,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.accent,
        secondary: AppColors.blue,
        error: AppColors.warn,
        surface: AppColors.surface,
        onPrimary: Colors.black,
        onSecondary: Colors.white,
        onSurface: AppColors.textPrimary,
      ),

      // AppBar
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: AppTextStyles.headlineMedium,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarBrightness: Brightness.dark,
          statusBarIconBrightness: Brightness.light,
        ),
      ),

      // Bottom Navigation
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: AppColors.surface,
        selectedItemColor: AppColors.accent,
        unselectedItemColor: AppColors.textMuted,
        showSelectedLabels: true,
        showUnselectedLabels: true,
        selectedLabelStyle: GoogleFonts.cairo(fontSize: 10, fontWeight: FontWeight.w700),
        unselectedLabelStyle: GoogleFonts.cairo(fontSize: 10),
        elevation: 0,
        type: BottomNavigationBarType.fixed,
      ),

      // Cards
      cardTheme: CardThemeData(
        color: AppColors.card,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: AppColors.border, width: 1),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      ),

      // Elevated Button
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.accent,
          foregroundColor: Colors.black,
          minimumSize: const Size(double.infinity, 52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: GoogleFonts.cairo(fontSize: 15, fontWeight: FontWeight.w800),
          elevation: 0,
        ),
      ),

      // Outlined Button
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.textPrimary,
          minimumSize: const Size(double.infinity, 52),
          side: const BorderSide(color: AppColors.border),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: GoogleFonts.cairo(fontSize: 15, fontWeight: FontWeight.w700),
        ),
      ),

      // Input fields
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.card,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.accent, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.warn),
        ),
        labelStyle: GoogleFonts.cairo(color: AppColors.textMuted, fontSize: 14),
        hintStyle: GoogleFonts.cairo(color: AppColors.textMuted, fontSize: 14),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),

      // Divider
      dividerTheme: const DividerThemeData(
        color: AppColors.border,
        thickness: 1,
        space: 1,
      ),

      // Text
      textTheme: TextTheme(
        displayLarge: AppTextStyles.displayLarge,
        displayMedium: AppTextStyles.displayMedium,
        headlineLarge: AppTextStyles.headlineLarge,
        headlineMedium: AppTextStyles.headlineMedium,
        titleLarge: AppTextStyles.titleLarge,
        titleMedium: AppTextStyles.titleMedium,
        bodyLarge: AppTextStyles.bodyLarge,
        bodyMedium: AppTextStyles.bodyMedium,
        bodySmall: AppTextStyles.bodySmall,
        labelLarge: AppTextStyles.labelLarge,
      ),

      // Chip
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.card2,
        selectedColor: AppColors.accentDim,
        labelStyle: GoogleFonts.cairo(fontSize: 12, fontWeight: FontWeight.w600),
        side: const BorderSide(color: AppColors.border),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }
}
