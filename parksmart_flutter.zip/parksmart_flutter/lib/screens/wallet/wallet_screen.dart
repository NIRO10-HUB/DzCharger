import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import '../../services/app_state.dart';
import '../../models/models.dart';

class WalletScreen extends ConsumerStatefulWidget {
  const WalletScreen({super.key});

  @override
  ConsumerState<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends ConsumerState<WalletScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String? _selectedPlanId;
  bool _recharging = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _recharge(double amount) async {
    setState(() => _recharging = true);
    await ref.read(authProvider.notifier).rechargeBalance(amount);
    await Future.delayed(const Duration(milliseconds: 600));
    if (mounted) {
      setState(() => _recharging = false);
      _showSuccess('\$${amount.toStringAsFixed(0)} تم إضافتها للرصيد');
    }
  }

  void _showSuccess(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700)),
      backgroundColor: AppColors.accent,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    final user = ref.watch(authProvider).user;
    final payments = ref.watch(paymentsProvider);
    final balance = user?.accountBalance ?? 0.0;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverToBoxAdapter(
            child: Column(
              children: [
                // Balance Header
                _WalletHeader(balance: balance, l: l),

                // Tab Bar
                Container(
                  color: AppColors.surface,
                  child: TabBar(
                    controller: _tabController,
                    labelColor: AppColors.accent,
                    unselectedLabelColor: AppColors.textMuted,
                    indicatorColor: AppColors.accent,
                    indicatorWeight: 2,
                    labelStyle: const TextStyle(
                      fontFamily: 'Cairo', fontSize: 13, fontWeight: FontWeight.w700,
                    ),
                    tabs: [
                      Tab(text: l.quickRecharge),
                      Tab(text: l.subscriptionPlans),
                      Tab(text: l.paymentHistory),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabController,
          children: [
            // ── Tab 1: Quick Recharge ──
            _buildRechargeTab(l),

            // ── Tab 2: Subscription Plans ──
            _buildPlansTab(l),

            // ── Tab 3: Transaction History ──
            _buildHistoryTab(payments, l),
          ],
        ),
      ),
    );
  }

  Widget _buildRechargeTab(AppLocalizations l) {
    final amounts = [5.0, 10.0, 20.0, 50.0];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          SectionHeader(title: l.quickRecharge),

          // Amount grid
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            childAspectRatio: 2.5,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: amounts.map((amount) => _AmountButton(
              amount: amount,
              onTap: () => _recharge(amount),
              loading: _recharging,
            ).animate(delay: Duration(milliseconds: 50 * amounts.indexOf(amount))).fade()).toList(),
          ),

          const SizedBox(height: 24),
          SectionHeader(title: 'مبلغ مخصص'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    keyboardType: TextInputType.number,
                    style: AppTextStyles.bodyLarge.copyWith(fontFamily: 'JetBrains Mono'),
                    decoration: InputDecoration(
                      hintText: '25.00',
                      prefixText: '\$ ',
                      prefixStyle: const TextStyle(
                        fontFamily: 'JetBrains Mono', color: AppColors.accent,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                AppButton(
                  label: l.recharge,
                  fullWidth: false,
                  style: const ButtonStyle(),
                  onPressed: () => _recharge(25),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),
          // Payment methods
          SectionHeader(title: 'طريقة الدفع'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                _PaymentMethodTile(emoji: '💳', label: 'بطاقة بنكية', sub: 'Visa / MasterCard', selected: true),
                const SizedBox(height: 10),
                _PaymentMethodTile(emoji: '🏦', label: 'تحويل بنكي', sub: 'CPA / BNA / BDL', selected: false),
                const SizedBox(height: 10),
                _PaymentMethodTile(emoji: '📱', label: 'Djezzy / Mobilis', sub: 'شحن عبر الرصيد الهاتفي', selected: false),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlansTab(AppLocalizations l) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          const SizedBox(height: 8),
          ...SubscriptionPlan.plans.asMap().entries.map((e) {
            final plan = e.value;
            final isSelected = _selectedPlanId == plan.id;
            return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: GestureDetector(
                onTap: () => setState(() => _selectedPlanId = plan.id),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: isSelected
                      ? LinearGradient(
                          colors: [plan.color.withOpacity(0.12), plan.color.withOpacity(0.06)],
                        )
                      : null,
                    color: isSelected ? null : AppColors.card,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? plan.color.withOpacity(0.5) : AppColors.border,
                      width: isSelected ? 1.5 : 1,
                    ),
                  ),
                  child: Stack(
                    children: [
                      if (plan.isPopular)
                        Positioned(
                          top: -4, right: -4,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.accent,
                              borderRadius: const BorderRadius.only(
                                topRight: Radius.circular(16),
                                bottomLeft: Radius.circular(10),
                              ),
                            ),
                            child: const Text('⭐ الأكثر شعبية', style: TextStyle(
                              fontFamily: 'Cairo', fontSize: 10, fontWeight: FontWeight.w700,
                              color: Colors.black,
                            )),
                          ),
                        ),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (plan.isPopular) const SizedBox(height: 12),
                                Text(plan.nameAr, style: AppTextStyles.headlineMedium),
                                const SizedBox(height: 6),
                                Text(
                                  l.hoursPerMonth(plan.hours),
                                  style: AppTextStyles.bodySmall,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  '= \$${(plan.price / (plan.hours * 60 / 5)).toStringAsFixed(3)} / 5 دقائق',
                                  style: AppTextStyles.bodySmall.copyWith(color: plan.color),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              MonoText('\$${plan.price.toStringAsFixed(0)}',
                                size: 30, color: plan.color),
                              const Text('/شهر', style: TextStyle(
                                fontFamily: 'Cairo', fontSize: 11, color: AppColors.textMuted,
                              )),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ).animate(delay: Duration(milliseconds: 100 * e.key)).slideY(begin: 0.1).fade(),
            );
          }),

          if (_selectedPlanId != null) ...[
            const SizedBox(height: 8),
            AppButton(
              label: '${l.subscribe} — ${SubscriptionPlan.plans.firstWhere((p) => p.id == _selectedPlanId).nameAr}',
              variant: AppButtonVariant.primary,
              onPressed: () {},
            ).animate().fade(),
          ],
        ],
      ),
    );
  }

  Widget _buildHistoryTab(List<PaymentModel> payments, AppLocalizations l) {
    if (payments.isEmpty) {
      return Center(child: Text(l.noData, style: AppTextStyles.bodySmall));
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: payments.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (_, i) {
        final p = payments[i];
        final isCredit = p.type == TransactionType.credit;
        return AppCard(
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: isCredit ? AppColors.accentDim : AppColors.blueDim,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(child: Text(p.icon, style: const TextStyle(fontSize: 20))),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(p.description, style: AppTextStyles.titleMedium),
                    const SizedBox(height: 3),
                    Text(_formatDate(p.createdAt), style: AppTextStyles.bodySmall),
                  ],
                ),
              ),
              MonoText(
                '${isCredit ? '+' : '-'}\$${p.amount.toStringAsFixed(2)}',
                size: 15,
                color: isCredit ? AppColors.accent : AppColors.warn,
              ),
            ],
          ),
        ).animate(delay: Duration(milliseconds: 50 * i)).fade();
      },
    );
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    if (dt.day == now.day) return 'اليوم، ${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}

// ─────────────────────────────────────────
//  Wallet Header
// ─────────────────────────────────────────
class _WalletHeader extends StatelessWidget {
  final double balance;
  final AppLocalizations l;

  const _WalletHeader({required this.balance, required this.l});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 60, 20, 28),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0D1A2E), Color(0xFF0A1218)],
        ),
      ),
      child: Column(
        children: [
          Text(l.availableBalance, style: AppTextStyles.bodySmall),
          const SizedBox(height: 8),
          MonoText('\$${balance.toStringAsFixed(2)}', size: 48, color: AppColors.accent,
            letterSpacing: 3),
          const SizedBox(height: 6),
          Text(
            '~ ${(balance / 0.25 * 5).toStringAsFixed(0)} دقيقة وقوف',
            style: AppTextStyles.bodySmall,
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Amount Button
// ─────────────────────────────────────────
class _AmountButton extends StatelessWidget {
  final double amount;
  final VoidCallback onTap;
  final bool loading;

  const _AmountButton({required this.amount, required this.onTap, required this.loading});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: loading ? null : onTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border),
        ),
        child: Center(
          child: MonoText(
            '\$${amount.toStringAsFixed(0)}',
            size: 22, color: AppColors.accent,
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Payment Method Tile
// ─────────────────────────────────────────
class _PaymentMethodTile extends StatelessWidget {
  final String emoji, label, sub;
  final bool selected;

  const _PaymentMethodTile({
    required this.emoji, required this.label,
    required this.sub, required this.selected,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      accent: selected,
      child: Row(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: AppTextStyles.titleMedium),
                Text(sub, style: AppTextStyles.bodySmall),
              ],
            ),
          ),
          if (selected)
            const Icon(Icons.check_circle_rounded, color: AppColors.accent, size: 20),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Needed for AppButton style param
// ─────────────────────────────────────────
extension on AppButton {
  AppButton get style => this;
}
