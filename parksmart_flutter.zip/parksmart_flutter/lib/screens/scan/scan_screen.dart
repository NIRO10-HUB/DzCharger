import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import '../../services/app_state.dart';
import '../../models/models.dart';

class ScanScreen extends ConsumerStatefulWidget {
  const ScanScreen({super.key});

  @override
  ConsumerState<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends ConsumerState<ScanScreen> {
  final MobileScannerController _controller = MobileScannerController();
  _ScanState _state = _ScanState.scanning;
  MeterModel? _scannedMeter;
  ZoneModel? _scannedZone;
  bool _torchOn = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_state != _ScanState.scanning) return;
    final barcode = capture.barcodes.firstOrNull;
    if (barcode?.rawValue == null) return;

    setState(() => _state = _ScanState.verifying);

    // Simulate QR verification
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!mounted) return;
      final meter = MeterModel.fromQr(barcode!.rawValue!);
      final zone = ZoneModel.mockZones.firstWhere(
        (z) => z.id == meter.zoneId,
        orElse: () => ZoneModel.mockZones[1],
      );
      setState(() {
        _scannedMeter = meter;
        _scannedZone = zone;
        _state = _ScanState.confirmed;
      });
    });
  }

  Future<void> _startSession() async {
    if (_scannedMeter == null || _scannedZone == null) return;
    setState(() => _state = _ScanState.starting);

    final user = ref.read(authProvider).user;
    final vehicles = ref.read(vehiclesProvider);
    if (user == null || vehicles.isEmpty) return;

    final defaultVehicle = vehicles.firstWhere(
      (v) => v.isDefault,
      orElse: () => vehicles.first,
    );

    final success = await ref.read(sessionProvider.notifier).startSession(
      userId: user.id,
      vehicleId: defaultVehicle.id,
      vehiclePlate: defaultVehicle.plateNumber,
      meter: _scannedMeter!,
      zone: _scannedZone!,
    );

    if (success && mounted) {
      ref.read(bottomNavIndexProvider.notifier).state = 2;
    }
  }

  void _reset() {
    setState(() {
      _state = _ScanState.scanning;
      _scannedMeter = null;
      _scannedZone = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          // Camera
          if (_state == _ScanState.scanning)
            MobileScanner(
              controller: _controller,
              onDetect: _onDetect,
            ),

          // Dark overlay for non-scanning states
          if (_state != _ScanState.scanning)
            Container(
              color: AppColors.bg,
              child: Center(child: _buildStateContent(l)),
            ),

          // Overlay UI (scanning state)
          if (_state == _ScanState.scanning)
            _buildScanOverlay(context, l),
        ],
      ),
    );
  }

  Widget _buildScanOverlay(BuildContext context, AppLocalizations l) {
    return SafeArea(
      child: Column(
        children: [
          // Top bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(l.scanQr, style: AppTextStyles.headlineMedium),
                IconButton(
                  icon: Icon(
                    _torchOn ? Icons.flash_on_rounded : Icons.flash_off_rounded,
                    color: _torchOn ? AppColors.gold : AppColors.textMuted,
                  ),
                  onPressed: () {
                    setState(() => _torchOn = !_torchOn);
                    _controller.toggleTorch();
                  },
                ),
              ],
            ),
          ),

          const Spacer(),

          // Viewfinder
          _QrViewfinder(),

          const SizedBox(height: 24),

          Text(l.scanQrDescription, style: AppTextStyles.bodySmall,
            textAlign: TextAlign.center),

          const Spacer(),

          // Meter info / instructions
          Padding(
            padding: const EdgeInsets.all(20),
            child: AppCard(
              child: Row(
                children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color: AppColors.accentDim,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Center(
                      child: Text('📡', style: TextStyle(fontSize: 22)),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('المنطقة B — وسط المدينة', style: AppTextStyles.titleMedium),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            MonoText('العداد #1283', size: 12, color: AppColors.textMuted),
                            const SizedBox(width: 12),
                            MonoText('\$0.25 / 5 دق', size: 12, color: AppColors.accent),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Demo: tap to simulate scan
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
            child: AppButton(
              label: '📷 ${l.scanning} (محاكاة)',
              onPressed: () => _onDetect(
                BarcodeCapture(barcodes: [
                  Barcode(rawValue: '{"meter_id":1283,"zone_id":"z_002","city":"Algiers"}'),
                ]),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStateContent(AppLocalizations l) {
    switch (_state) {
      case _ScanState.verifying:
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              width: 60, height: 60,
              child: CircularProgressIndicator(
                color: AppColors.accent,
                strokeWidth: 3,
              ),
            ),
            const SizedBox(height: 24),
            Text(l.verifying, style: AppTextStyles.headlineMedium),
            const SizedBox(height: 8),
            Text(l.scanQr, style: AppTextStyles.bodySmall),
          ],
        ).animate().fade();

      case _ScanState.confirmed:
        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('✅', style: TextStyle(fontSize: 72))
                .animate().scaleXY(begin: 0.5, end: 1, duration: 600.ms, curve: Curves.elasticOut),

              const SizedBox(height: 20),

              Text(l.scanSuccess, style: AppTextStyles.headlineLarge.copyWith(
                color: AppColors.accent,
              )).animate(delay: 200.ms).slideY(begin: 0.2).fade(),

              const SizedBox(height: 32),

              // Meter Details Card
              AppCard(
                accent: true,
                child: Column(
                  children: [
                    _DetailRow(label: l.zone, value: _scannedZone?.name ?? '—'),
                    const SizedBox(height: 12),
                    _DetailRow(label: l.meterNumber, value: '#${_scannedMeter?.id ?? '—'}', mono: true),
                    const SizedBox(height: 12),
                    _DetailRow(
                      label: l.pricePerFiveMin,
                      value: '\$${_scannedZone?.pricePerFiveMin.toStringAsFixed(2) ?? '—'}',
                      mono: true, valueColor: AppColors.accent,
                    ),
                    const Divider(height: 24, color: AppColors.border),
                    _DetailRow(label: l.vehiclePlate, value: '123-ABC', mono: true),
                  ],
                ),
              ).animate(delay: 300.ms).slideY(begin: 0.2).fade(),

              const SizedBox(height: 24),

              AppButton(
                label: l.startParking,
                loading: _state == _ScanState.starting,
                onPressed: _startSession,
              ).animate(delay: 400.ms).fade(),

              const SizedBox(height: 12),

              AppButton(
                label: l.cancel,
                variant: AppButtonVariant.ghost,
                onPressed: _reset,
              ).animate(delay: 450.ms).fade(),
            ],
          ),
        );

      case _ScanState.starting:
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🚀', style: TextStyle(fontSize: 64)),
            const SizedBox(height: 16),
            Text(l.startingSession, style: AppTextStyles.headlineMedium),
          ],
        ).animate().fade();

      default:
        return const SizedBox();
    }
  }
}

enum _ScanState { scanning, verifying, confirmed, starting }

// ─────────────────────────────────────────
//  QR Viewfinder (animated corners)
// ─────────────────────────────────────────
class _QrViewfinder extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 240, height: 240,
      child: Stack(
        children: [
          // Corners
          _Corner(top: 0, right: 0, isTop: true, isLeft: false),
          _Corner(top: 0, left: 0, isTop: true, isLeft: true),
          _Corner(bottom: 0, right: 0, isTop: false, isLeft: false),
          _Corner(bottom: 0, left: 0, isTop: false, isLeft: true),

          // Scan line
          Positioned.fill(
            child: ClipRect(
              child: Align(
                alignment: Alignment.topCenter,
                child: Container(
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Colors.transparent, AppColors.accent, Colors.transparent],
                    ),
                    boxShadow: [BoxShadow(
                      color: AppColors.accent.withOpacity(0.5),
                      blurRadius: 8,
                    )],
                  ),
                )
                .animate(onPlay: (c) => c.repeat())
                .moveY(begin: 10, end: 220, duration: 2000.ms, curve: Curves.easeInOut)
                .then()
                .moveY(begin: 220, end: 10, duration: 2000.ms, curve: Curves.easeInOut),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Corner extends StatelessWidget {
  final double? top, bottom, left, right;
  final bool isTop, isLeft;

  const _Corner({
    this.top, this.bottom, this.left, this.right,
    required this.isTop, required this.isLeft,
  });

  @override
  Widget build(BuildContext context) {
    final borderRadius = BorderRadius.only(
      topLeft: isTop && isLeft ? const Radius.circular(12) : Radius.zero,
      topRight: isTop && !isLeft ? const Radius.circular(12) : Radius.zero,
      bottomLeft: !isTop && isLeft ? const Radius.circular(12) : Radius.zero,
      bottomRight: !isTop && !isLeft ? const Radius.circular(12) : Radius.zero,
    );

    return Positioned(
      top: top, bottom: bottom, left: left, right: right,
      child: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          border: Border(
            top: isTop ? const BorderSide(color: AppColors.accent, width: 3) : BorderSide.none,
            bottom: !isTop ? const BorderSide(color: AppColors.accent, width: 3) : BorderSide.none,
            left: isLeft ? const BorderSide(color: AppColors.accent, width: 3) : BorderSide.none,
            right: !isLeft ? const BorderSide(color: AppColors.accent, width: 3) : BorderSide.none,
          ),
          borderRadius: borderRadius,
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final bool mono;
  final Color? valueColor;

  const _DetailRow({
    required this.label, required this.value,
    this.mono = false, this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTextStyles.bodySmall),
        mono
          ? MonoText(value, size: 13, color: valueColor)
          : Text(value, style: AppTextStyles.titleMedium.copyWith(color: valueColor)),
      ],
    );
  }
}
