import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../theme/app_theme.dart';
import '../../services/app_state.dart';
import '../home/home_screen.dart';
import '../scan/scan_screen.dart';
import '../session/session_screen.dart';
import '../wallet/wallet_screen.dart';
import '../other_screens.dart';

class MainShell extends ConsumerWidget {
  const MainShell({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context)!;
    final index = ref.watch(bottomNavIndexProvider);
    final sessionState = ref.watch(sessionProvider);

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));

    final screens = [
      const HomeScreen(),
      const ScanScreen(),
      const SessionScreen(),
      const WalletScreen(),
      const HistoryScreen(),
    ];

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: IndexedStack(
        index: index,
        children: screens,
      ),
      bottomNavigationBar: _ParkSmartBottomNav(
        currentIndex: index,
        hasActiveSession: sessionState.hasActiveSession,
        l: l,
        onTap: (i) => ref.read(bottomNavIndexProvider.notifier).state = i,
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Custom Bottom Navigation
// ─────────────────────────────────────────
class _ParkSmartBottomNav extends StatelessWidget {
  final int currentIndex;
  final bool hasActiveSession;
  final AppLocalizations l;
  final ValueChanged<int> onTap;

  const _ParkSmartBottomNav({
    required this.currentIndex,
    required this.hasActiveSession,
    required this.l,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final items = [
      _NavItem(icon: '🏠', label: l.home, index: 0),
      _NavItem(icon: '📷', label: l.scan, index: 1),
      _NavItem(icon: '⏱', label: l.session, index: 2,
        hasBadge: hasActiveSession),
      _NavItem(icon: '💳', label: l.wallet, index: 3),
      _NavItem(icon: '📋', label: l.history, index: 4),
    ];

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(top: BorderSide(color: AppColors.border)),
        boxShadow: [
          BoxShadow(color: Color(0x40000000), blurRadius: 20, offset: Offset(0, -4)),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: items.map((item) => _NavButton(
              item: item,
              isActive: currentIndex == item.index,
              onTap: onTap,
            )).toList(),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  final String icon, label;
  final int index;
  final bool hasBadge;

  const _NavItem({
    required this.icon, required this.label,
    required this.index, this.hasBadge = false,
  });
}

class _NavButton extends StatelessWidget {
  final _NavItem item;
  final bool isActive;
  final ValueChanged<int> onTap;

  const _NavButton({
    required this.item, required this.isActive, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: () => onTap(item.index),
        behavior: HitTestBehavior.opaque,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  AnimatedDefaultTextStyle(
                    duration: const Duration(milliseconds: 200),
                    style: TextStyle(
                      fontSize: isActive ? 24 : 22,
                    ),
                    child: Text(
                      item.icon,
                      style: TextStyle(
                        fontSize: isActive ? 24 : 22,
                        shadows: isActive ? [
                          Shadow(
                            color: AppColors.accent.withOpacity(0.6),
                            blurRadius: 12,
                          ),
                        ] : null,
                      ),
                    ),
                  ),
                  if (item.hasBadge)
                    Positioned(
                      top: -4, right: -4,
                      child: Container(
                        width: 10, height: 10,
                        decoration: BoxDecoration(
                          color: AppColors.accent,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.surface, width: 1.5),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 10,
                  fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                  color: isActive ? AppColors.accent : AppColors.textMuted,
                ),
                child: Text(item.label),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
