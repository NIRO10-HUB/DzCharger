import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import '../../services/app_state.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context)!;
    final user = ref.watch(authProvider).user;
    final sessionState = ref.watch(sessionProvider);

    if (user == null) return const SizedBox();

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: CustomScrollView(
        slivers: [
          // ── Header ──
          SliverToBoxAdapter(
            child: _HomeHeader(user: user, l: l, ref: ref),
          ),

          // ── Active Session ──
          if (sessionState.hasActiveSession)
            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SectionHeader(title: l.activeSession),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _ActiveSessionCard(
                      session: sessionState.activeSession!,
                      onView: () => _navigate(context, ref, 2),
                      l: l,
                    ),
                  ),
                ],
              ),
            ),

          // ── Quick Actions ──
          SliverToBoxAdapter(
            child: SectionHeader(title: l.quickActions),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 2.8,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              delegate: SliverChildListDelegate([
                QuickActionTile(
                  icon: '📷', label: l.scanQr, subtitle: l.startParking,
                  iconBg: AppColors.accentDim,
                  onTap: () => _navigate(context, ref, 1),
                ).animate(delay: 100.ms).slideY(begin: 0.2).fade(),
                QuickActionTile(
                  icon: '📋', label: l.parkingHistory, subtitle: l.history,
                  iconBg: AppColors.blueDim,
                  onTap: () => _navigate(context, ref, 4),
                ).animate(delay: 150.ms).slideY(begin: 0.2).fade(),
                QuickActionTile(
                  icon: '💳', label: l.wallet, subtitle: l.recharge,
                  iconBg: AppColors.goldDim,
                  onTap: () => _navigate(context, ref, 3),
                ).animate(delay: 200.ms).slideY(begin: 0.2).fade(),
                QuickActionTile(
                  icon: '🚗', label: l.myVehicles, subtitle: '',
                  iconBg: AppColors.purpleDim,
                  onTap: () => Navigator.of(context).pushNamed('/vehicles'),
                ).animate(delay: 250.ms).slideY(begin: 0.2).fade(),
              ]),
            ),
          ),

          // ── Stats ──
          SliverToBoxAdapter(
            child: SectionHeader(title: l.myStats),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: 1.6,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              delegate: SliverChildListDelegate([
                StatCard(value: '47', label: l.totalSessions, color: AppColors.accent)
                  .animate(delay: 300.ms).fade(),
                StatCard(value: '\$23.5', label: l.thisMonth, color: AppColors.blue)
                  .animate(delay: 350.ms).fade(),
                StatCard(value: '0', label: l.violations, color: AppColors.warn)
                  .animate(delay: 400.ms).fade(),
              ]),
            ),
          ),

          const SliverToBoxAdapter(child: SizedBox(height: 24)),
        ],
      ),
    );
  }

  void _navigate(BuildContext context, WidgetRef ref, int index) {
    ref.read(bottomNavIndexProvider.notifier).state = index;
  }
}

// ─────────────────────────────────────────
//  Home Header
// ─────────────────────────────────────────
class _HomeHeader extends StatelessWidget {
  final UserModel user;
  final AppLocalizations l;
  final WidgetRef ref;

  const _HomeHeader({required this.user, required this.l, required this.ref});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 60, 20, 28),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0D1A2E), Color(0xFF0A1218)],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(l.hello, style: const TextStyle(
                    fontFamily: 'Cairo', fontSize: 13,
                    color: AppColors.textMuted,
                  )),
                  const SizedBox(height: 2),
                  Text(user.name, style: AppTextStyles.headlineLarge),
                ],
              ),
              Stack(
                children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: const Center(
                      child: Text('🔔', style: TextStyle(fontSize: 20)),
                    ),
                  ),
                  Positioned(
                    top: 0, left: 0,
                    child: Container(
                      width: 18, height: 18,
                      decoration: BoxDecoration(
                        color: AppColors.warn,
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.bg, width: 2),
                      ),
                      child: const Center(
                        child: Text('3', style: TextStyle(
                          fontSize: 9, fontWeight: FontWeight.w700, color: Colors.white,
                        )),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),
          BalanceCard(
            balance: user.accountBalance,
            onAddPressed: () => ref.read(bottomNavIndexProvider.notifier).state = 3,
          ),
        ],
      ),
    ).animate().fade(duration: 400.ms);
  }
}

// ─────────────────────────────────────────
//  Active Session Card (on Home)
// ─────────────────────────────────────────
class _ActiveSessionCard extends StatefulWidget {
  final ParkingSessionModel session;
  final VoidCallback onView;
  final AppLocalizations l;

  const _ActiveSessionCard({
    required this.session, required this.onView, required this.l,
  });

  @override
  State<_ActiveSessionCard> createState() => _ActiveSessionCardState();
}

class _ActiveSessionCardState extends State<_ActiveSessionCard> {
  late Duration _elapsed;

  @override
  void initState() {
    super.initState();
    _elapsed = DateTime.now().difference(widget.session.startTime);
    _startTimer();
  }

  void _startTimer() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        setState(() => _elapsed = DateTime.now().difference(widget.session.startTime));
        _startTimer();
      }
    });
  }

  String get _formattedTime {
    final h = _elapsed.inHours.toString().padLeft(2, '0');
    final m = (_elapsed.inMinutes % 60).toString().padLeft(2, '0');
    final s = (_elapsed.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  double get _cost => (_elapsed.inMinutes / 5).ceil() * widget.session.pricePerFiveMin;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      accent: true,
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          // Top bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0x1400E5A0), Color(0x0A1A8CFF)],
              ),
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                StatusBadge(label: widget.l.sessionActive, withDot: true),
                Text(widget.session.zoneName, style: const TextStyle(
                  fontFamily: 'Cairo', fontSize: 12, color: AppColors.textMuted,
                )),
              ],
            ),
          ),

          // Body
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InfoRow(
                      label: widget.l.vehiclePlate,
                      value: widget.session.vehiclePlate, mono: true,
                    ),
                    InfoRow(
                      label: widget.l.startTime,
                      value: _formatTime(widget.session.startTime),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Big Timer
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: AppColors.accentDim,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Center(
                    child: MonoText(
                      _formattedTime,
                      size: 34, color: AppColors.accent, letterSpacing: 5,
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                Row(
                  children: [
                    Expanded(
                      child: AppButton(
                        label: widget.l.session,
                        onPressed: widget.onView,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: AppButton(
                        label: widget.l.stopSession,
                        variant: AppButtonVariant.danger,
                        onPressed: () {},
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ).animate().slideY(begin: 0.1).fade(delay: 200.ms);
  }

  String _formatTime(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }
}
