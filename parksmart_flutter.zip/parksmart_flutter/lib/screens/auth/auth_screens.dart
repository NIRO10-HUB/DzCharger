import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import '../../services/app_state.dart';

// ─────────────────────────────────────────
//  Splash Screen
// ─────────────────────────────────────────
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.of(context).pushReplacementNamed('/login');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo
            Container(
              width: 100, height: 100,
              decoration: BoxDecoration(
                gradient: AppColors.gradientAccent,
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x6600E5A0),
                    blurRadius: 40, offset: Offset(0, 10),
                  ),
                ],
              ),
              child: const Center(
                child: Text('🅿️', style: TextStyle(fontSize: 50)),
              ),
            )
            .animate()
            .scaleXY(begin: 0.5, end: 1, duration: 600.ms, curve: Curves.elasticOut)
            .fade(duration: 400.ms),

            const SizedBox(height: 24),

            const Text(
              'ParkSmart',
              style: TextStyle(
                fontFamily: 'Cairo', fontSize: 36,
                fontWeight: FontWeight.w900, color: AppColors.textPrimary,
              ),
            )
            .animate(delay: 300.ms)
            .slideY(begin: 0.3, end: 0, duration: 500.ms)
            .fade(duration: 400.ms),

            const SizedBox(height: 8),

            const Text(
              'نظام المواقف الذكي | Système intelligent | Smart Parking',
              style: TextStyle(
                fontFamily: 'Cairo', fontSize: 12,
                color: AppColors.textMuted,
              ),
              textAlign: TextAlign.center,
            )
            .animate(delay: 500.ms)
            .fade(duration: 500.ms),

            const SizedBox(height: 60),

            SizedBox(
              width: 40,
              child: LinearProgressIndicator(
                backgroundColor: AppColors.card,
                valueColor: const AlwaysStoppedAnimation(AppColors.accent),
                borderRadius: BorderRadius.circular(2),
              ),
            )
            .animate(delay: 600.ms)
            .fade(duration: 400.ms),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Login Screen
// ─────────────────────────────────────────
class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _phoneCtrl = TextEditingController(text: '0555 123 456');
  final _passCtrl = TextEditingController(text: 'password123');
  bool _obscure = true;
  bool _loading = false;

  @override
  void dispose() {
    _phoneCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    setState(() => _loading = true);
    await ref.read(authProvider.notifier).login(_phoneCtrl.text, _passCtrl.text);
    if (mounted) Navigator.of(context).pushReplacementNamed('/home');
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),

              // Logo + Title
              Center(
                child: Column(
                  children: [
                    Container(
                      width: 80, height: 80,
                      decoration: BoxDecoration(
                        gradient: AppColors.gradientAccent,
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x5000E5A0),
                            blurRadius: 32, offset: Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Text('🅿️', style: TextStyle(fontSize: 40)),
                      ),
                    ).animate().scaleXY(begin: 0.7, end: 1, duration: 500.ms, curve: Curves.easeOut),

                    const SizedBox(height: 16),

                    Text(l.appName, style: AppTextStyles.displayMedium)
                      .animate(delay: 100.ms).slideY(begin: 0.3).fade(),

                    const SizedBox(height: 4),

                    Text(l.appTagline, style: AppTextStyles.bodySmall)
                      .animate(delay: 200.ms).fade(),
                  ],
                ),
              ),

              const SizedBox(height: 48),

              // Phone Field
              _buildLabel(l.phoneNumber),
              const SizedBox(height: 8),
              TextField(
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                style: AppTextStyles.bodyLarge.copyWith(fontFamily: 'JetBrains Mono'),
                decoration: InputDecoration(
                  hintText: '+213 555 123 456',
                  prefixIcon: const Padding(
                    padding: EdgeInsets.all(14),
                    child: Text('📞', style: TextStyle(fontSize: 18)),
                  ),
                ),
              ).animate(delay: 300.ms).slideX(begin: 0.1).fade(),

              const SizedBox(height: 16),

              // Password Field
              _buildLabel(l.password),
              const SizedBox(height: 8),
              TextField(
                controller: _passCtrl,
                obscureText: _obscure,
                style: AppTextStyles.bodyLarge,
                decoration: InputDecoration(
                  hintText: '••••••••',
                  prefixIcon: const Padding(
                    padding: EdgeInsets.all(14),
                    child: Text('🔒', style: TextStyle(fontSize: 18)),
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                      color: AppColors.textMuted,
                    ),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  ),
                ),
              ).animate(delay: 350.ms).slideX(begin: 0.1).fade(),

              const SizedBox(height: 12),

              // Forgot password
              Align(
                alignment: Alignment.centerLeft,
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pushNamed('/forgot-password'),
                  child: Text(l.forgotPassword, style: AppTextStyles.bodySmall.copyWith(
                    color: AppColors.accent, fontWeight: FontWeight.w600,
                  )),
                ),
              ),

              const SizedBox(height: 28),

              // Login Button
              AppButton(
                label: l.login,
                loading: _loading,
                onPressed: _login,
              ).animate(delay: 400.ms).slideY(begin: 0.2).fade(),

              const SizedBox(height: 16),

              // Language Switcher
              _LanguageSwitcher().animate(delay: 450.ms).fade(),

              const SizedBox(height: 24),

              // Register link
              Center(
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pushNamed('/register'),
                  child: RichText(
                    text: TextSpan(
                      text: '${l.noAccount} ',
                      style: AppTextStyles.bodySmall,
                      children: [
                        TextSpan(
                          text: l.register,
                          style: AppTextStyles.bodySmall.copyWith(
                            color: AppColors.accent, fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ).animate(delay: 500.ms).fade(),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String text) => Text(text, style: AppTextStyles.bodySmall.copyWith(
    fontWeight: FontWeight.w700, color: AppColors.textMuted,
  ));
}

// ─────────────────────────────────────────
//  Language Switcher Widget
// ─────────────────────────────────────────
class _LanguageSwitcher extends ConsumerWidget {
  const _LanguageSwitcher();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentLocale = ref.watch(languageProvider);
    final langs = [
      (code: 'ar', label: 'العربية', flag: '🇩🇿'),
      (code: 'fr', label: 'Français', flag: '🇫🇷'),
      (code: 'en', label: 'English', flag: '🇬🇧'),
    ];

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: langs.map((lang) {
        final isActive = currentLocale.languageCode == lang.code;
        return GestureDetector(
          onTap: () => ref.read(languageProvider.notifier).setLanguage(lang.code),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: isActive ? AppColors.accentDim : AppColors.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: isActive ? AppColors.borderAccent : AppColors.border,
              ),
            ),
            child: Row(
              children: [
                Text(lang.flag, style: const TextStyle(fontSize: 14)),
                const SizedBox(width: 6),
                Text(lang.label, style: TextStyle(
                  fontFamily: 'Cairo', fontSize: 12, fontWeight: FontWeight.w600,
                  color: isActive ? AppColors.accent : AppColors.textMuted,
                )),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

// ─────────────────────────────────────────
//  Register Screen
// ─────────────────────────────────────────
class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  int _step = 0; // 0: form, 1: OTP
  bool _loading = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_step == 0) {
      setState(() => _step = 1);
      return;
    }
    setState(() => _loading = true);
    await ref.read(authProvider.notifier).register(
      name: _nameCtrl.text,
      phone: _phoneCtrl.text,
      email: _emailCtrl.text,
      password: _passCtrl.text,
    );
    if (mounted) Navigator.of(context).pushReplacementNamed('/home');
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: AppColors.accent),
          onPressed: () => _step == 1
            ? setState(() => _step = 0)
            : Navigator.pop(context),
        ),
        title: Text(_step == 0 ? l.register : l.otp),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: _step == 0 ? _buildForm(l) : _buildOtp(l),
        ),
      ),
    );
  }

  Widget _buildForm(AppLocalizations l) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(l.welcome, style: AppTextStyles.displayMedium),
        const SizedBox(height: 4),
        Text(l.appTagline, style: AppTextStyles.bodySmall),
        const SizedBox(height: 32),

        _Field(label: l.fullName, ctrl: _nameCtrl, hint: 'أحمد بن كريم', emoji: '👤'),
        const SizedBox(height: 16),
        _Field(label: l.phoneNumber, ctrl: _phoneCtrl, hint: '+213 555 xxx xxx', emoji: '📞',
          keyboardType: TextInputType.phone),
        const SizedBox(height: 16),
        _Field(label: l.email, ctrl: _emailCtrl, hint: 'email@example.com', emoji: '📧',
          keyboardType: TextInputType.emailAddress),
        const SizedBox(height: 16),
        _Field(label: l.password, ctrl: _passCtrl, hint: '••••••••', emoji: '🔒',
          obscure: true),
        const SizedBox(height: 32),

        AppButton(label: l.next, onPressed: _submit),
        const SizedBox(height: 16),

        Center(
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: RichText(
              text: TextSpan(
                text: '${l.haveAccount} ',
                style: AppTextStyles.bodySmall,
                children: [
                  TextSpan(
                    text: l.login,
                    style: AppTextStyles.bodySmall.copyWith(
                      color: AppColors.accent, fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildOtp(AppLocalizations l) {
    final otpControllers = List.generate(6, (_) => TextEditingController());
    return Column(
      children: [
        const Text('📱', style: TextStyle(fontSize: 64)),
        const SizedBox(height: 16),
        Text(l.otp, style: AppTextStyles.displayMedium),
        const SizedBox(height: 8),
        Text('${l.otpSent} ${_phoneCtrl.text}', style: AppTextStyles.bodySmall,
          textAlign: TextAlign.center),
        const SizedBox(height: 40),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(6, (i) => SizedBox(
            width: 46, height: 56,
            child: TextField(
              controller: otpControllers[i],
              keyboardType: TextInputType.number,
              maxLength: 1,
              textAlign: TextAlign.center,
              style: AppTextStyles.monoMedium.copyWith(fontSize: 20),
              decoration: const InputDecoration(counterText: ''),
              onChanged: (v) {
                if (v.isNotEmpty && i < 5) {
                  FocusScope.of(context).nextFocus();
                }
              },
            ),
          )),
        ),
        const SizedBox(height: 32),
        AppButton(
          label: l.otpVerify,
          loading: _loading,
          onPressed: _submit,
        ),
        const SizedBox(height: 16),
        Center(
          child: Text(l.resendOtp, style: AppTextStyles.bodySmall.copyWith(
            color: AppColors.accent, fontWeight: FontWeight.w600,
          )),
        ),
      ],
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final TextEditingController ctrl;
  final String hint;
  final String emoji;
  final TextInputType? keyboardType;
  final bool obscure;

  const _Field({
    required this.label, required this.ctrl,
    required this.hint, required this.emoji,
    this.keyboardType, this.obscure = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTextStyles.bodySmall.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        TextField(
          controller: ctrl,
          keyboardType: keyboardType,
          obscureText: obscure,
          style: AppTextStyles.bodyLarge,
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(emoji, style: const TextStyle(fontSize: 18)),
            ),
          ),
        ),
      ],
    );
  }
}
