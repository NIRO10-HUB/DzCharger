import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import '../../services/app_state.dart';
import '../../models/models.dart';

// ═════════════════════════════════════════
//  History Screen
// ═════════════════════════════════════════
class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context)!;
    final sessions = ref.watch(sessionProvider).history;

    final totalCost = sessions.fold<double>(0, (sum, s) => sum + s.cost);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: CustomScrollView(
        slivers: [
          // Header
          SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 60, 20, 24),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [Color(0xFF0D1A2E), Color(0xFF0A1218)],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(l.parkingHistory, style: AppTextStyles.displayMedium),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      _StatPill(value: '${sessions.length}', label: l.totalSessions,
                        color: AppColors.accent),
                      const SizedBox(width: 12),
                      _StatPill(value: '\$${totalCost.toStringAsFixed(2)}',
                        label: l.totalPaid, color: AppColors.blue),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Filter Chips
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _FilterChip(label: l.completed, active: true),
                    const SizedBox(width: 8),
                    _FilterChip(label: l.violation, active: false),
                    const SizedBox(width: 8),
                    _FilterChip(label: l.thisMonth, active: false),
                  ],
                ),
              ),
            ),
          ),

          // List
          sessions.isEmpty
            ? SliverFillRemaining(
                child: Center(child: Text(l.noData, style: AppTextStyles.bodySmall)),
              )
            : SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (_, i) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _SessionHistoryItem(session: sessions[i], l: l)
                        .animate(delay: Duration(milliseconds: 60 * i)).slideY(begin: 0.1).fade(),
                    ),
                    childCount: sessions.length,
                  ),
                ),
              ),

          const SliverToBoxAdapter(child: SizedBox(height: 24)),
        ],
      ),
    );
  }
}

class _StatPill extends StatelessWidget {
  final String value, label;
  final Color color;

  const _StatPill({required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          MonoText(value, size: 16, color: color),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(
            fontFamily: 'Cairo', fontSize: 11, color: AppColors.textMuted,
          )),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;

  const _FilterChip({required this.label, required this.active});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: active ? AppColors.accentDim : AppColors.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: active ? AppColors.borderAccent : AppColors.border,
        ),
      ),
      child: Text(label, style: TextStyle(
        fontFamily: 'Cairo', fontSize: 12, fontWeight: FontWeight.w700,
        color: active ? AppColors.accent : AppColors.textMuted,
      )),
    );
  }
}

class _SessionHistoryItem extends StatelessWidget {
  final ParkingSessionModel session;
  final AppLocalizations l;

  const _SessionHistoryItem({required this.session, required this.l});

  @override
  Widget build(BuildContext context) {
    final isViolation = session.status == SessionStatus.cancelled;
    final color = isViolation ? AppColors.warn : AppColors.accent;
    final bgColor = isViolation ? AppColors.warnDim : AppColors.accentDim;

    return AppCard(
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(14)),
            child: Center(child: Text(isViolation ? '⚠️' : '🅿️',
              style: const TextStyle(fontSize: 22))),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(session.zoneName, style: AppTextStyles.titleMedium,
                  overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Text(_formatDate(session.startTime), style: AppTextStyles.bodySmall),
                const SizedBox(height: 6),
                Row(
                  children: [
                    StatusBadge(
                      label: isViolation ? l.violation : l.completed,
                      color: isViolation ? BadgeColor.warn : BadgeColor.accent,
                    ),
                    const SizedBox(width: 8),
                    if (!isViolation && session.endTime != null)
                      StatusBadge(
                        label: l.minutes(session.elapsed.inMinutes),
                        color: BadgeColor.muted,
                      ),
                  ],
                ),
              ],
            ),
          ),
          MonoText('\$${session.cost.toStringAsFixed(2)}', size: 15, color: color),
        ],
      ),
    );
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    if (dt.day == now.day) return 'اليوم، ${dt.hour}:${dt.minute.toString().padLeft(2,'0')}';
    if (dt.day == now.subtract(const Duration(days: 1)).day) return 'أمس';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}

// ═════════════════════════════════════════
//  Vehicles Screen
// ═════════════════════════════════════════
class VehiclesScreen extends ConsumerWidget {
  const VehiclesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context)!;
    final vehicles = ref.watch(vehiclesProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        title: Text(l.myVehicles),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: AppColors.accent),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded, color: AppColors.accent),
            onPressed: () => _showAddVehicle(context, ref, l),
          ),
        ],
      ),
      body: vehicles.isEmpty
        ? Center(child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('🚗', style: TextStyle(fontSize: 64)),
              const SizedBox(height: 16),
              Text(l.addVehicle, style: AppTextStyles.headlineMedium),
              const SizedBox(height: 24),
              AppButton(
                label: '+ ${l.addVehicle}',
                fullWidth: false,
                onPressed: () => _showAddVehicle(context, ref, l),
              ),
            ],
          ))
        : ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: vehicles.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (_, i) => _VehicleTile(
              vehicle: vehicles[i], l: l,
              onSetDefault: () => ref.read(vehiclesProvider.notifier).setDefault(vehicles[i].id),
              onDelete: () => ref.read(vehiclesProvider.notifier).removeVehicle(vehicles[i].id),
            ).animate(delay: Duration(milliseconds: 80 * i)).slideY(begin: 0.1).fade(),
          ),
    );
  }

  void _showAddVehicle(BuildContext context, WidgetRef ref, AppLocalizations l) {
    final plateCtrl = TextEditingController();
    final modelCtrl = TextEditingController();
    VehicleType type = VehicleType.car;

    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.card,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setModalState) => Padding(
          padding: EdgeInsets.fromLTRB(24, 16, 24,
            24 + MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              )),
              const SizedBox(height: 20),
              Text(l.addVehicle, style: AppTextStyles.headlineMedium),
              const SizedBox(height: 20),

              // Vehicle Type
              Row(
                children: VehicleType.values.map((t) {
                  final icons = {VehicleType.car: '🚗', VehicleType.motorcycle: '🏍️', VehicleType.truck: '🚛'};
                  final labels = {VehicleType.car: l.car, VehicleType.motorcycle: l.motorcycle, VehicleType.truck: l.truck};
                  final isSelected = type == t;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () => setModalState(() => type = t),
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: isSelected ? AppColors.accentDim : AppColors.card2,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isSelected ? AppColors.borderAccent : AppColors.border,
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(icons[t]!, style: const TextStyle(fontSize: 24)),
                            const SizedBox(height: 4),
                            Text(labels[t]!, style: TextStyle(
                              fontFamily: 'Cairo', fontSize: 11,
                              color: isSelected ? AppColors.accent : AppColors.textMuted,
                              fontWeight: FontWeight.w700,
                            )),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 16),
              _TextField(label: l.vehiclePlate, ctrl: plateCtrl, hint: '123-ABC'),
              const SizedBox(height: 12),
              _TextField(label: l.vehicleModel, ctrl: modelCtrl, hint: 'Toyota Camry 2021'),
              const SizedBox(height: 20),

              AppButton(
                label: l.save,
                onPressed: () {
                  if (plateCtrl.text.isEmpty) return;
                  ref.read(vehiclesProvider.notifier).addVehicle(VehicleModel(
                    id: 'veh_${DateTime.now().millisecondsSinceEpoch}',
                    userId: 'usr_001',
                    plateNumber: plateCtrl.text.toUpperCase(),
                    vehicleType: type,
                    model: modelCtrl.text,
                    isDefault: false,
                    createdAt: DateTime.now(),
                  ));
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _VehicleTile extends StatelessWidget {
  final VehicleModel vehicle;
  final AppLocalizations l;
  final VoidCallback onSetDefault;
  final VoidCallback onDelete;

  const _VehicleTile({
    required this.vehicle, required this.l,
    required this.onSetDefault, required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return AppCard(
      accent: vehicle.isDefault,
      child: Row(
        children: [
          Text(vehicle.typeIcon, style: const TextStyle(fontSize: 36)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    MonoText(vehicle.plateNumber, size: 16),
                    if (vehicle.isDefault) ...[
                      const SizedBox(width: 8),
                      StatusBadge(label: l.defaultVehicle),
                    ],
                  ],
                ),
                const SizedBox(height: 3),
                Text(vehicle.model, style: AppTextStyles.bodySmall),
              ],
            ),
          ),
          PopupMenuButton<String>(
            color: AppColors.card2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            icon: const Icon(Icons.more_vert_rounded, color: AppColors.textMuted),
            onSelected: (v) {
              if (v == 'default') onSetDefault();
              if (v == 'delete') onDelete();
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'default', child: Text(l.defaultVehicle,
                style: const TextStyle(fontFamily: 'Cairo', color: AppColors.textPrimary))),
              PopupMenuItem(value: 'delete', child: Text(l.delete,
                style: const TextStyle(fontFamily: 'Cairo', color: AppColors.warn))),
            ],
          ),
        ],
      ),
    );
  }
}

class _TextField extends StatelessWidget {
  final String label, hint;
  final TextEditingController ctrl;

  const _TextField({required this.label, required this.ctrl, required this.hint});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTextStyles.bodySmall.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          style: AppTextStyles.bodyLarge,
          decoration: InputDecoration(hintText: hint),
        ),
      ],
    );
  }
}

// ═════════════════════════════════════════
//  Profile Screen
// ═════════════════════════════════════════
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context)!;
    final user = ref.watch(authProvider).user;
    final currentLocale = ref.watch(languageProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 60, 20, 28),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [Color(0xFF0D1A2E), Color(0xFF0A1218)],
                ),
              ),
              child: Column(
                children: [
                  Container(
                    width: 80, height: 80,
                    decoration: BoxDecoration(
                      gradient: AppColors.gradientAccent,
                      shape: BoxShape.circle,
                      boxShadow: const [
                        BoxShadow(color: Color(0x4000E5A0), blurRadius: 24),
                      ],
                    ),
                    child: Center(child: Text(
                      user?.name.substring(0, 1) ?? 'أ',
                      style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: Colors.black),
                    )),
                  ),
                  const SizedBox(height: 12),
                  Text(user?.name ?? '', style: AppTextStyles.headlineLarge),
                  const SizedBox(height: 4),
                  Text(user?.phone ?? '', style: AppTextStyles.bodySmall.copyWith(
                    fontFamily: 'JetBrains Mono',
                  )),
                ],
              ),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Language Section
                _SectionLabel(l.language),
                const SizedBox(height: 8),
                AppCard(
                  child: Row(
                    children: [
                      (code: 'ar', label: 'العربية', flag: '🇩🇿'),
                      (code: 'fr', label: 'Français', flag: '🇫🇷'),
                      (code: 'en', label: 'English', flag: '🇬🇧'),
                    ].map((lang) {
                      final isActive = currentLocale.languageCode == lang.code;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () => ref.read(languageProvider.notifier).setLanguage(lang.code),
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 3),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: isActive ? AppColors.accentDim : Colors.transparent,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: isActive ? AppColors.borderAccent : Colors.transparent,
                              ),
                            ),
                            child: Column(
                              children: [
                                Text(lang.flag, style: const TextStyle(fontSize: 20)),
                                const SizedBox(height: 4),
                                Text(lang.label, style: TextStyle(
                                  fontFamily: 'Cairo', fontSize: 10,
                                  color: isActive ? AppColors.accent : AppColors.textMuted,
                                  fontWeight: FontWeight.w700,
                                )),
                              ],
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),

                const SizedBox(height: 20),
                _SectionLabel(l.settings),
                const SizedBox(height: 8),

                // Settings Tiles
                ...[
                  (icon: '🔒', label: l.changePassword, action: () {}),
                  (icon: '🚗', label: l.myVehicles, action: () => Navigator.of(context).pushNamed('/vehicles')),
                  (icon: '🔔', label: l.notifications, action: () {}),
                  (icon: '📄', label: l.privacyPolicy, action: () {}),
                  (icon: 'ℹ️', label: l.about, action: () {}),
                ].map((item) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: AppCard(
                    onTap: item.action,
                    child: Row(
                      children: [
                        Text(item.icon, style: const TextStyle(fontSize: 20)),
                        const SizedBox(width: 14),
                        Expanded(child: Text(item.label, style: AppTextStyles.titleMedium)),
                        const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted, size: 20),
                      ],
                    ),
                  ),
                )),

                const SizedBox(height: 12),

                // Logout
                AppButton(
                  label: l.logout,
                  variant: AppButtonVariant.danger,
                  onPressed: () {
                    ref.read(authProvider.notifier).logout();
                    Navigator.of(context).pushReplacementNamed('/login');
                  },
                ),

                const SizedBox(height: 32),
                Center(child: Text(
                  '${l.appName} v1.0.0 — الجزائر',
                  style: AppTextStyles.bodySmall,
                )),
                const SizedBox(height: 16),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(text, style: AppTextStyles.bodySmall.copyWith(
        fontWeight: FontWeight.w700, letterSpacing: 0.5,
      )),
    );
  }
}
