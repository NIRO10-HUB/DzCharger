import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../theme/app_theme.dart';
import '../../widgets/widgets.dart';
import '../../services/app_state.dart';

class SessionScreen extends ConsumerStatefulWidget {
  const SessionScreen({super.key});

  @override
  ConsumerState<SessionScreen> createState() => _SessionScreenState();
}

class _SessionScreenState extends ConsumerState<SessionScreen> {
  Duration _elapsed = Duration.zero;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    Future.delayed(const Duration(seconds: 1), () {
      if (!mounted) return;
      final session = ref.read(sessionProvider).activeSession;
      if (session != null) {
        setState(() => _elapsed = DateTime.now().difference(session.startTime));
      }
      _startTimer();
    });
  }

  String get _formattedTime {
    final h = _elapsed.inHours.toString().padLeft(2, '0');
    final m = (_elapsed.inMinutes % 60).toString().padLeft(2, '0');
    final s = (_elapsed.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  Future<void> _stopSession(AppLocalizations l) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(l.sessionStopConfirm, style: AppTextStyles.titleLarge),
        content: Text(l.sessionStopWarning, style: AppTextStyles.bodySmall),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(l.cancel, style: const TextStyle(
              fontFamily: 'Cairo', color: AppColors.textMuted,
            )),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(l.stopSession, style: const TextStyle(
              fontFamily: 'Cairo', color: AppColors.warn, fontWeight: FontWeight.w700,
            )),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      final ended = await ref.read(sessionProvider.notifier).stopSession();
      if (ended != null && mounted) {
        _showSessionSummary(ended, l);
      }
    }
  }

  void _showSessionSummary(ParkingSessionModel session, AppLocalizations l) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (_) => _SessionSummarySheet(session: session, l: l),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    final sessionState = ref.watch(sessionProvider);
    final user = ref.watch(authProvider).user;

    if (!sessionState.hasActiveSession) {
      return _NoSessionView(l: l, onScan: () {
        ref.read(bottomNavIndexProvider.notifier).state = 1;
      });
    }

    final session = sessionState.activeSession!;
    final cost = (_elapsed.inMinutes / 5).ceil() * session.pricePerFiveMin;
    final periodProgress = (_elapsed.inSeconds % 300) / 300;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Zone Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 60, 20, 24),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF0D1A2E), Color(0xFF081420)],
                ),
              ),
              child: Column(
                children: [
                  StatusBadge(label: l.sessionActive, withDot: true),
                  const SizedBox(height: 12),
                  Text(session.zoneName, style: AppTextStyles.headlineLarge,
                    textAlign: TextAlign.center),
                  const SizedBox(height: 4),
                  Text(
                    '${l.meter} #${session.meterId} — الجزائر العاصمة',
                    style: AppTextStyles.bodySmall,
                  ),
                ],
              ),
            ).animate().fade(duration: 400.ms),

            // Big Timer
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 28, 20, 8),
              child: Column(
                children: [
                  Text(l.elapsedTime, style: AppTextStyles.bodySmall),
                  const SizedBox(height: 8),
                  MonoText(
                    _formattedTime,
                    size: 56,
                    color: AppColors.accent,
                    letterSpacing: 6,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${l.currentCost}:  \$${cost.toStringAsFixed(2)}',
                    style: AppTextStyles.bodyMedium.copyWith(color: AppColors.textMuted),
                  ),
                ],
              ),
            ).animate(delay: 100.ms).fade().slideY(begin: 0.1),

            // Progress Bar (5min intervals)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'الفترة الحالية (${_elapsed.inMinutes % 5}/5 دق)',
                        style: AppTextStyles.bodySmall,
                      ),
                      Text('\$${session.pricePerFiveMin} قادمة',
                        style: AppTextStyles.bodySmall.copyWith(color: AppColors.accent)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: periodProgress,
                      backgroundColor: AppColors.card,
                      valueColor: const AlwaysStoppedAnimation(AppColors.accent),
                      minHeight: 6,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Info Grid
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: GridView.count(
                crossAxisCount: 2,
                childAspectRatio: 2.2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  AppCard(child: InfoRow(
                    label: l.vehiclePlate, value: session.vehiclePlate, mono: true,
                  )),
                  AppCard(child: InfoRow(
                    label: l.meterNumber, value: '#${session.meterId}', mono: true,
                  )),
                  AppCard(child: InfoRow(
                    label: l.startTime, value: _formatTime(session.startTime),
                  )),
                  AppCard(child: InfoRow(
                    label: l.pricePerFiveMin,
                    value: '\$${session.pricePerFiveMin.toStringAsFixed(2)}',
                    mono: true, valueColor: AppColors.accent,
                  )),
                ],
              ).animate(delay: 200.ms).fade(),
            ),

            const SizedBox(height: 12),

            // Balance remaining
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: AppCard(
                accent: true,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(l.remainingBalance, style: AppTextStyles.bodySmall),
                    MonoText(
                      '\$${user?.accountBalance.toStringAsFixed(2) ?? '0.00'}',
                      size: 20, color: AppColors.accent,
                    ),
                  ],
                ),
              ).animate(delay: 250.ms).fade(),
            ),

            const SizedBox(height: 20),

            // Action Buttons
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
              child: Row(
                children: [
                  Expanded(
                    child: AppButton(
                      label: l.extendSession,
                      variant: AppButtonVariant.ghost,
                      onPressed: () {},
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: AppButton(
                      label: l.stopSession,
                      variant: AppButtonVariant.danger,
                      onPressed: () => _stopSession(l),
                    ),
                  ),
                ],
              ).animate(delay: 300.ms).slideY(begin: 0.2).fade(),
            ),
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime dt) {
    return '${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}';
  }
}

// ─────────────────────────────────────────
//  No Session View
// ─────────────────────────────────────────
class _NoSessionView extends StatelessWidget {
  final AppLocalizations l;
  final VoidCallback onScan;

  const _NoSessionView({required this.l, required this.onScan});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('🅿️', style: TextStyle(fontSize: 80)),
              const SizedBox(height: 20),
              Text(l.noActiveSession, style: AppTextStyles.headlineLarge,
                textAlign: TextAlign.center),
              const SizedBox(height: 12),
              Text(l.startParking, style: AppTextStyles.bodySmall,
                textAlign: TextAlign.center),
              const SizedBox(height: 32),
              AppButton(
                label: '📷 ${l.scanQr}',
                onPressed: onScan,
                fullWidth: false,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────
//  Session Summary Bottom Sheet
// ─────────────────────────────────────────
class _SessionSummarySheet extends StatelessWidget {
  final ParkingSessionModel session;
  final AppLocalizations l;

  const _SessionSummarySheet({required this.session, required this.l});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 36),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: AppColors.border, borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 20),
          const Text('✅', style: TextStyle(fontSize: 56)),
          const SizedBox(height: 12),
          Text(l.sessionEnded, style: AppTextStyles.headlineLarge.copyWith(
            color: AppColors.accent,
          )),
          const SizedBox(height: 24),
          _SummaryRow(label: l.duration, value: _formatDuration(session.elapsed)),
          const SizedBox(height: 12),
          _SummaryRow(label: l.totalCost, value: '\$${session.cost.toStringAsFixed(2)}',
            valueColor: AppColors.accent, mono: true),
          const SizedBox(height: 12),
          _SummaryRow(label: l.zone, value: session.zoneName),
          const SizedBox(height: 24),
          AppButton(
            label: l.done,
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  String _formatDuration(Duration d) {
    if (d.inHours > 0) return '${d.inHours}س ${d.inMinutes % 60}د';
    return '${d.inMinutes}د ${d.inSeconds % 60}ث';
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  final bool mono;

  const _SummaryRow({required this.label, required this.value, this.valueColor, this.mono = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: AppTextStyles.bodySmall),
        mono
          ? MonoText(value, size: 15, color: valueColor)
          : Text(value, style: AppTextStyles.titleMedium.copyWith(color: valueColor)),
      ],
    );
  }
}
