// ─────────────────────────────────────────
//  ParkSmart — Data Models
// ─────────────────────────────────────────

import 'package:flutter/material.dart';

// ── User ──────────────────────────────────
class UserModel {
  final String id;
  final String name;
  final String phone;
  final String email;
  final double accountBalance;
  final String status;
  final DateTime createdAt;
  final List<VehicleModel> vehicles;

  const UserModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    required this.accountBalance,
    this.status = 'active',
    required this.createdAt,
    this.vehicles = const [],
  });

  UserModel copyWith({
    double? accountBalance,
    List<VehicleModel>? vehicles,
    String? name,
    String? email,
  }) {
    return UserModel(
      id: id,
      name: name ?? this.name,
      phone: phone,
      email: email ?? this.email,
      accountBalance: accountBalance ?? this.accountBalance,
      status: status,
      createdAt: createdAt,
      vehicles: vehicles ?? this.vehicles,
    );
  }

  factory UserModel.mock() => UserModel(
    id: 'usr_001',
    name: 'أحمد بن كريم',
    phone: '0555 123 456',
    email: 'ahmed@example.com',
    accountBalance: 12.75,
    createdAt: DateTime(2025, 6, 1),
    vehicles: [
      VehicleModel(
        id: 'veh_001',
        userId: 'usr_001',
        plateNumber: '123-ABC',
        vehicleType: VehicleType.car,
        model: 'Toyota Camry 2021',
        isDefault: true,
        createdAt: DateTime(2025, 6, 1),
      ),
      VehicleModel(
        id: 'veh_002',
        userId: 'usr_001',
        plateNumber: '456-DEF',
        vehicleType: VehicleType.car,
        model: 'Hyundai Elantra 2019',
        isDefault: false,
        createdAt: DateTime(2025, 8, 15),
      ),
    ],
  );
}

// ── Vehicle ───────────────────────────────
enum VehicleType { car, motorcycle, truck }

class VehicleModel {
  final String id;
  final String userId;
  final String plateNumber;
  final VehicleType vehicleType;
  final String model;
  final bool isDefault;
  final DateTime createdAt;

  const VehicleModel({
    required this.id,
    required this.userId,
    required this.plateNumber,
    required this.vehicleType,
    required this.model,
    this.isDefault = false,
    required this.createdAt,
  });

  String get typeIcon {
    switch (vehicleType) {
      case VehicleType.car: return '🚗';
      case VehicleType.motorcycle: return '🏍️';
      case VehicleType.truck: return '🚛';
    }
  }
}

// ── Zone ──────────────────────────────────
class ZoneModel {
  final String id;
  final String name;
  final String nameFr;
  final String nameEn;
  final double pricePerFiveMin;
  final String city;
  final bool isActive;
  final int totalMeters;
  final int availableMeters;

  const ZoneModel({
    required this.id,
    required this.name,
    required this.nameFr,
    required this.nameEn,
    required this.pricePerFiveMin,
    required this.city,
    this.isActive = true,
    required this.totalMeters,
    required this.availableMeters,
  });

  int get occupancyPercent => totalMeters > 0
    ? ((totalMeters - availableMeters) * 100 ~/ totalMeters)
    : 0;

  static List<ZoneModel> get mockZones => [
    const ZoneModel(
      id: 'z_001', name: 'المنطقة A — الميناء',
      nameFr: 'Zone A — Port', nameEn: 'Zone A — Port',
      pricePerFiveMin: 0.25, city: 'Algiers',
      totalMeters: 120, availableMeters: 22,
    ),
    const ZoneModel(
      id: 'z_002', name: 'المنطقة B — وسط المدينة',
      nameFr: 'Zone B — Centre-ville', nameEn: 'Zone B — Downtown',
      pricePerFiveMin: 0.25, city: 'Algiers',
      totalMeters: 150, availableMeters: 38,
    ),
    const ZoneModel(
      id: 'z_003', name: 'المنطقة C — المطار',
      nameFr: 'Zone C — Aéroport', nameEn: 'Zone C — Airport',
      pricePerFiveMin: 0.30, city: 'Algiers',
      totalMeters: 80, availableMeters: 43,
    ),
  ];
}

// ── Meter ─────────────────────────────────
class MeterModel {
  final String id;
  final String zoneId;
  final String meterCode;
  final double latitude;
  final double longitude;
  final MeterStatus status;
  final String qrData;

  const MeterModel({
    required this.id,
    required this.zoneId,
    required this.meterCode,
    required this.latitude,
    required this.longitude,
    required this.status,
    required this.qrData,
  });

  factory MeterModel.fromQr(String qrJson) {
    // Parse QR: {"meter_id":1283,"zone_id":"z_002","city":"Algiers","signature":"..."}
    return const MeterModel(
      id: '1283',
      zoneId: 'z_002',
      meterCode: 'MTR-1283',
      latitude: 36.7372,
      longitude: 3.0865,
      status: MeterStatus.active,
      qrData: '{"meter_id":1283,"zone_id":"z_002","city":"Algiers"}',
    );
  }
}

enum MeterStatus { active, maintenance, offline }

// ── Parking Session ───────────────────────
enum SessionStatus { active, paused, completed, cancelled }

class ParkingSessionModel {
  final String id;
  final String userId;
  final String vehicleId;
  final String meterId;
  final String zoneId;
  final String zoneName;
  final String vehiclePlate;
  final DateTime startTime;
  final DateTime? endTime;
  final double pricePerFiveMin;
  final SessionStatus status;
  final double cost;

  const ParkingSessionModel({
    required this.id,
    required this.userId,
    required this.vehicleId,
    required this.meterId,
    required this.zoneId,
    required this.zoneName,
    required this.vehiclePlate,
    required this.startTime,
    this.endTime,
    required this.pricePerFiveMin,
    required this.status,
    this.cost = 0.0,
  });

  Duration get elapsed => (endTime ?? DateTime.now()).difference(startTime);

  double get currentCost {
    final minutes = elapsed.inMinutes;
    return (minutes / 5).ceil() * pricePerFiveMin;
  }

  String get elapsedFormatted {
    final d = elapsed;
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  ParkingSessionModel copyWith({SessionStatus? status, DateTime? endTime, double? cost}) {
    return ParkingSessionModel(
      id: id, userId: userId, vehicleId: vehicleId,
      meterId: meterId, zoneId: zoneId, zoneName: zoneName,
      vehiclePlate: vehiclePlate, startTime: startTime,
      pricePerFiveMin: pricePerFiveMin,
      status: status ?? this.status,
      endTime: endTime ?? this.endTime,
      cost: cost ?? this.cost,
    );
  }

  static List<ParkingSessionModel> get mockHistory => [
    ParkingSessionModel(
      id: 'sess_001', userId: 'usr_001', vehicleId: 'veh_001',
      meterId: '1283', zoneId: 'z_002', zoneName: 'المنطقة B — وسط المدينة',
      vehiclePlate: '123-ABC', pricePerFiveMin: 0.25,
      startTime: DateTime.now().subtract(const Duration(hours: 2)),
      endTime: DateTime.now().subtract(const Duration(hours: 1, minutes: 30)),
      status: SessionStatus.completed, cost: 1.50,
    ),
    ParkingSessionModel(
      id: 'sess_002', userId: 'usr_001', vehicleId: 'veh_001',
      meterId: '1101', zoneId: 'z_001', zoneName: 'المنطقة A — الميناء',
      vehiclePlate: '123-ABC', pricePerFiveMin: 0.25,
      startTime: DateTime.now().subtract(const Duration(days: 1, hours: 4)),
      endTime: DateTime.now().subtract(const Duration(days: 1, hours: 2, minutes: 45)),
      status: SessionStatus.completed, cost: 3.75,
    ),
    ParkingSessionModel(
      id: 'sess_003', userId: 'usr_001', vehicleId: 'veh_002',
      meterId: '2020', zoneId: 'z_003', zoneName: 'المنطقة C — المطار',
      vehiclePlate: '456-DEF', pricePerFiveMin: 0.30,
      startTime: DateTime.now().subtract(const Duration(days: 3)),
      endTime: DateTime.now().subtract(const Duration(days: 3)),
      status: SessionStatus.completed, cost: 2.50,
    ),
  ];
}

// ── Payment ───────────────────────────────
enum PaymentMethod { wallet, creditCard, bankTransfer, subscription }
enum PaymentStatus { pending, completed, failed, refunded }
enum TransactionType { credit, debit }

class PaymentModel {
  final String id;
  final String userId;
  final double amount;
  final PaymentMethod method;
  final PaymentStatus status;
  final TransactionType type;
  final String description;
  final DateTime createdAt;
  final String? sessionId;

  const PaymentModel({
    required this.id,
    required this.userId,
    required this.amount,
    required this.method,
    required this.status,
    required this.type,
    required this.description,
    required this.createdAt,
    this.sessionId,
  });

  String get icon => type == TransactionType.credit ? '⬆️' : '🅿️';

  static List<PaymentModel> get mockHistory => [
    PaymentModel(
      id: 'pay_001', userId: 'usr_001', amount: 10.0,
      method: PaymentMethod.creditCard, status: PaymentStatus.completed,
      type: TransactionType.credit, description: 'Recharge',
      createdAt: DateTime.now().subtract(const Duration(hours: 3)),
    ),
    PaymentModel(
      id: 'pay_002', userId: 'usr_001', amount: 1.50,
      method: PaymentMethod.wallet, status: PaymentStatus.completed,
      type: TransactionType.debit, description: 'Parking — Zone B',
      createdAt: DateTime.now().subtract(const Duration(hours: 2)),
      sessionId: 'sess_001',
    ),
    PaymentModel(
      id: 'pay_003', userId: 'usr_001', amount: 20.0,
      method: PaymentMethod.creditCard, status: PaymentStatus.completed,
      type: TransactionType.credit, description: 'Recharge',
      createdAt: DateTime.now().subtract(const Duration(days: 5)),
    ),
  ];
}

// ── Violation ─────────────────────────────
enum ViolationStatus { pending, paid, contested, cancelled }

class ViolationModel {
  final String id;
  final String vehiclePlate;
  final String meterId;
  final String officerId;
  final DateTime violationTime;
  final double fineAmount;
  final ViolationStatus status;
  final String zone;

  const ViolationModel({
    required this.id,
    required this.vehiclePlate,
    required this.meterId,
    required this.officerId,
    required this.violationTime,
    required this.fineAmount,
    required this.status,
    required this.zone,
  });
}

// ── Subscription Plan ─────────────────────
class SubscriptionPlan {
  final String id;
  final String nameAr;
  final String nameFr;
  final String nameEn;
  final int hours;
  final double price;
  final bool isPopular;
  final Color color;

  const SubscriptionPlan({
    required this.id,
    required this.nameAr,
    required this.nameFr,
    required this.nameEn,
    required this.hours,
    required this.price,
    this.isPopular = false,
    required this.color,
  });

  static const List<SubscriptionPlan> plans = [
    SubscriptionPlan(
      id: 'plan_basic',
      nameAr: 'الأساسي', nameFr: 'Basique', nameEn: 'Basic',
      hours: 30, price: 10.0, isPopular: false,
      color: Color(0xFF1A8CFF),
    ),
    SubscriptionPlan(
      id: 'plan_advanced',
      nameAr: 'المتقدم', nameFr: 'Avancé', nameEn: 'Advanced',
      hours: 70, price: 20.0, isPopular: true,
      color: Color(0xFF00E5A0),
    ),
  ];
}
